package com.resellic.client

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Icon
import androidx.compose.runtime.*
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch

data class Route(val name: String, val arg: String = "")

/** পেছনে যাওয়ার স্ট্যাক সহ সরল নেভিগেশন */
class Nav {
    val stack: SnapshotStateList<Route> = mutableStateListOf(Route("home"))
    val top get() = stack.last()
    fun push(name: String, arg: String = "") { stack.add(Route(name, arg)) }
    fun tab(name: String) { stack.clear(); stack.add(Route(name)) }
    fun back(): Boolean { if (stack.size > 1) { stack.removeAt(stack.size - 1); return true }; return false }
    fun replace(name: String, arg: String = "") { stack.removeAt(stack.size - 1); stack.add(Route(name, arg)) }
}

val LocalNav = compositionLocalOf { Nav() }

fun openUrl(ctx: Context, url: String) {
    try { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {}
}

class MainActivity : ComponentActivity() {
    val askNotif = registerForActivityResult(androidx.activity.result.contract.ActivityResultContracts.RequestPermission()) { }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Session.init(applicationContext)
        enableEdgeToEdge(statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT), navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT))
        setContent { ResellicTheme { Root() } }
    }
}

private val guestTabs = listOf(Tab("home", "Home", I.Home), Tab("search", "Domains", I.Globe), Tab("plans", "Hosting", I.Server), Tab("chat", "Support", I.Headset), Tab("login", "Log in", I.Person))
private val userTabs = listOf(Tab("home", "Home", I.Home), Tab("domains", "Domains", I.Globe), Tab("services", "Services", I.Server), Tab("billing", "Billing", I.Receipt), Tab("account", "Account", I.Person))

private fun tabOf(r: String): String? = when (r) {
    "home", "search", "plans", "chat", "login", "domains", "services", "billing", "account" -> r
    "register", "forgot" -> "login"
    "domain" -> "domains"
    "hosting" -> "services"
    "invoice" -> "billing"
    "tickets", "ticket", "ticket_new", "profile", "password", "wallet" -> "account"
    "menu", "all_services", "posts", "post" -> null
    else -> null
}

private fun titleOf(r: Route): String? = when (r.name) {
    "search" -> "Domains"; "plans" -> "Web Hosting"; "chat" -> "Live Chat"; "login" -> "Log In"; "register" -> "Create Account"
    "forgot" -> "Reset Password"; "domains" -> "My Domains"; "domain" -> "Domain"; "services" -> "My Services"; "hosting" -> "Hosting"
    "billing" -> "Billing"; "invoice" -> "Invoice"; "account" -> "Account"; "tickets" -> "Support Tickets"; "ticket" -> "Ticket"
    "ticket_new" -> "New Ticket"; "profile" -> "Edit Profile"; "password" -> "Change Password"; "wallet" -> "Wallet"
    "menu" -> "Menu"; "all_services" -> "All Services"; "notifications" -> "Notifications"
    else -> null
}

/** অর্ডার/অনলাইন পেমেন্ট সাইটের নিরাপদ পাতায় — ফোনের ব্রাউজারে এক-বারের লিংক */
fun goSite(ctx: Context, nav: Nav, scope: kotlinx.coroutines.CoroutineScope, path: String, onBusy: (Boolean) -> Unit = {}) {
    if (!Session.loggedIn) { nav.replaceAuth("register"); return }
    scope.launch {
        onBusy(true)
        val j = Api.call("go", "", org.json.JSONObject().put("path", path), true)
        onBusy(false)
        if (j.optBoolean("ok")) openUrl(ctx, j.s("url")) else openUrl(ctx, SITE)
    }
}

@Composable
fun Root() {
    var splash by remember { mutableStateOf(true) }
    androidx.compose.animation.Crossfade(targetState = splash, animationSpec = androidx.compose.animation.core.tween(350), label = "splash") { on ->
        if (on) Splash { splash = false } else AppShell()
    }
}

@Composable
fun AppShell() {
    val nav = remember { Nav() }
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val logged = Session.loggedIn
    // লগআউট/সেশন শেষ হলে হোমে
    LaunchedEffect(logged) { nav.tab("home") }
    // লগইন করা থাকলে নোটিশ চালু: অনুমতি, ১৫ মিনিটের চেক, Firebase টোকেন
    LaunchedEffect(logged) {
        if (logged) {
            Notifier.channel(ctx); Notifier.schedule(ctx); Notifier.registerPush()
            if (android.os.Build.VERSION.SDK_INT >= 33 && !Notifier.canShow(ctx)) (ctx as? MainActivity)?.askNotif?.launch(android.Manifest.permission.POST_NOTIFICATIONS)
            Notifier.sync(ctx)
        }
    }
    var unread by remember { mutableIntStateOf(0) }
    LaunchedEffect(logged, nav.top.name) { if (logged) unread = Api.call("me", "", null, true).optInt("notifications", 0) else unread = 0 }
    BackHandler(enabled = nav.stack.size > 1) { nav.back() }
    val r = nav.top
    val tabs = if (logged) userTabs else guestTabs
    val current = tabOf(r.name) ?: (if (r.name in listOf("menu", "all_services", "posts", "post")) null else "home")
    val isRoot = r.name in tabs.map { it.key }
    val title = titleOf(r)

    CompositionLocalProvider(LocalNav provides nav) {
        Column(Modifier.fillMaxSize().background(Color.White)) {
            // উপরের বার (লগইন/রেজিস্টার নিজেই নিজের নীল হেডার আঁকে)
            val bare = r.name == "login" || r.name == "register" || r.name == "forgot"
            if (!bare) {
                if (r.name == "menu") {
                    TopBar(title = null) {
                        RoundBtn(I.Cart, { goSite(ctx, nav, scope, "cart.php") })
                        RoundBtn(I.Close, { nav.back() }, solid = true)
                    }
                } else if (isRoot) {
                    TopBar(title = if (r.name == "home") null else title) {
                        RoundBtn(I.Cart, { goSite(ctx, nav, scope, "cart.php") })
                        if (logged) RoundBtn(I.Bell, { nav.push("notifications") }, badge = unread)
                        if (!logged) RoundBtn(I.Menu, { nav.push("menu") })
                    }
                } else {
                    TopBar(title = title, onBack = { nav.back() })
                }
            }
            Box(Modifier.weight(1f).fillMaxWidth()) {
                Content(r)
                // লগইন করা ইউজারের ভাসমান চ্যাট বাটন
                if (logged && isRoot && r.name != "chat") {
                    Box(Modifier.align(Alignment.BottomEnd).padding(18.dp).size(56.dp).shadow(10.dp, CircleShape).clip(CircleShape)
                        .background(Color(0xFFEA580C)).clickable { nav.push("chat") }, Alignment.Center) {
                        Icon(I.Chat, null, tint = Color.White, modifier = Modifier.size(26.dp)) }
                }
            }
            BottomBar(tabs, current) { k -> nav.tab(k) }
        }
    }
}

@Composable
fun Content(r: Route) {
    val logged = Session.loggedIn
    when (r.name) {
        "home" -> if (logged) UserHome() else GuestHome()
        "search" -> SearchScreen(r.arg)
        "plans" -> PlansScreen()
        "all_services" -> AllServicesScreen()
        "menu" -> MenuScreen()
        "posts" -> PostsScreen()
        "post" -> PostScreen(r.arg)
        "login" -> LoginScreen()
        "register" -> RegisterScreen()
        "forgot" -> ForgotScreen()
        "chat" -> ChatScreen()
        else -> if (!logged) LoginScreen() else when (r.name) {
            "domains" -> DomainsScreen()
            "domain" -> DomainDetailScreen(r.arg)
            "services" -> ServicesScreen()
            "hosting" -> HostingDetailScreen(r.arg)
            "billing" -> BillingScreen()
            "invoice" -> InvoiceScreen(r.arg)
            "account" -> AccountScreen()
            "tickets" -> TicketsScreen()
            "ticket" -> TicketScreen(r.arg)
            "ticket_new" -> NewTicketScreen()
            "profile" -> ProfileScreen()
            "password" -> PasswordScreen()
            "wallet" -> WalletScreen()
            "notifications" -> NotificationsScreen()
            else -> UserHome()
        }
    }
}
