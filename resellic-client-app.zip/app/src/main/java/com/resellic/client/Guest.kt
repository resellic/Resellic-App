package com.resellic.client

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import org.json.JSONObject

/* ===================== ভিজিটর হোম ===================== */
@Composable
fun GuestHome() {
    val nav = LocalNav.current
    val ctx = LocalContext.current
    var tick by remember { mutableIntStateOf(0) }
    val res = load("home", "home", tick = tick)
    var q by remember { mutableStateOf("") }
    Screen(gap = 12.dp) {
        // ডোমেইন সার্চ বক্স
        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(26.dp)).border(1.5.dp, C.Line, RoundedCornerShape(26.dp))
            .background(Brush.linearGradient(listOf(Color(0xFFE8EEFF), Color(0xFFF6F8FF)))).padding(horizontal = 14.dp, vertical = 16.dp)) {
            Row(Modifier.clip(RoundedCornerShape(99.dp)).background(Color.White).border(1.dp, C.Line, RoundedCornerShape(99.dp)).padding(horizontal = 11.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(I.Globe, null, tint = C.Blue, modifier = Modifier.size(14.dp)); Spacer(Modifier.width(6.dp))
                Text("Domain search", color = C.Blue, fontSize = 11.5.sp, fontWeight = FontWeight.ExtraBold)
            }
            Spacer(Modifier.height(9.dp))
            Text(buildAnnotatedString { append("Find your perfect "); withStyle(SpanStyle(color = C.Blue)) { append("domain") } },
                color = C.Ink, fontSize = 25.sp, fontWeight = FontWeight.ExtraBold, lineHeight = 29.sp)
            Text("Register in minutes. Pay with bKash, Nagad or card.", color = C.Muted, fontSize = 12.5.sp, modifier = Modifier.padding(top = 4.dp, bottom = 12.dp))
            Row(Modifier.fillMaxWidth().height(56.dp).clip(RoundedCornerShape(18.dp)).background(Color.White).border(2.dp, C.Blue, RoundedCornerShape(18.dp)).padding(start = 14.dp, end = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(I.Search, null, tint = C.Blue, modifier = Modifier.size(22.dp)); Spacer(Modifier.width(8.dp))
                androidx.compose.foundation.text.BasicTextField(q, { q = it }, Modifier.weight(1f), singleLine = true,
                    textStyle = androidx.compose.ui.text.TextStyle(color = C.Ink, fontSize = 15.sp),
                    decorationBox = { inner -> if (q.isEmpty()) Text("yourname.com", color = C.Muted, fontSize = 15.sp); inner() })
                Btn("Search", { if (q.isNotBlank()) nav.tab2("search", q.trim()) }, Modifier.width(96.dp), style = BtnStyle.Amber, h = 42.dp)
            }
            Spacer(Modifier.height(10.dp))
            val tlds = res.json?.optJSONArray("tlds")
            if (tlds != null) Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                for (n in 0 until minOf(3, tlds.length())) {
                    val t = tlds.getJSONObject(n); val on = n == 0
                    Column(Modifier.weight(1f).clip(RoundedCornerShape(16.dp)).background(if (on) C.Blue else Color.White)
                        .border(1.5.dp, if (on) C.Blue else C.Line, RoundedCornerShape(16.dp)).padding(vertical = 9.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(t.s("tld"), color = if (on) Color.White else C.Ink, fontSize = 16.sp, fontWeight = FontWeight.ExtraBold)
                        Text(t.s("price_txt"), color = if (on) Color(0xFFFFD27A) else C.Blue, fontSize = 11.5.sp, fontWeight = FontWeight.ExtraBold)
                    }
                }
            }
        }
        // ছোট সুবিধার টাইল
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Feat(I.Bolt, "Instant", C.TileBlue, C.Blue, Modifier.weight(1f))
            Feat(I.Shield, "Secure", C.TileGreen, C.Green, Modifier.weight(1f))
            Feat(I.Wallet, "bKash", C.TileAmber, C.Orange, Modifier.weight(1f))
            Feat(I.Wallet, "Nagad", C.TileRose, C.Coral, Modifier.weight(1f))
        }
        // জয়েন ব্যানার
        Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp)).background(C.Blue)) {
            Box(Modifier.align(Alignment.TopEnd).offset(x = 12.dp, y = (-28).dp).size(88.dp).clip(CircleShape).background(C.Amber))
            Column(Modifier.padding(horizontal = 20.dp, vertical = 14.dp)) {
                Text("Refer friends and earn on every domain", color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.ExtraBold, lineHeight = 24.sp, modifier = Modifier.padding(end = 70.dp))
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Btn("Create account", { nav.push("register") }, Modifier.weight(1f), style = BtnStyle.Amber, h = 44.dp)
                    Btn("Log In", { nav.tab("login") }, Modifier.weight(1f), style = BtnStyle.Soft, h = 44.dp)
                }
            }
        }
        // সার্ভিস
        BandCard("Our Services", I.Grid, "All services", { nav.push("all_services") }) {
            val plans = res.json?.optJSONArray("plans")
            val minPlan = plans?.let { a -> (0 until a.length()).map { a.getJSONObject(it) }.firstOrNull() }
            RowCard(I.Server, C.TileBlue, C.Blue, "Web Hosting", "NVMe SSD · Free SSL", right = {
                if (minPlan != null) Text("from " + minPlan.s("price_txt"), color = C.Blue, fontSize = 12.sp, fontWeight = FontWeight.ExtraBold); Spacer(Modifier.width(8.dp)); ArrowDot() }, onClick = { nav.tab("plans") })
            RowCard(I.Globe, C.TileGreen, C.Green, "Domains", ".com, .xyz, .shop and more", right = { ArrowDot() }, onClick = { nav.tab("search") })
        }
        if (res.error != null) Loaded(res, { tick++ }) {}
    }
}

/** ট্যাব বদলে একটা আর্গুমেন্ট সহ যাওয়া */
fun Nav.tab2(name: String, arg: String) { stack.clear(); stack.add(Route(name, arg)) }

@Composable
fun Feat(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, bg: Color, fg: Color, m: Modifier) {
    Column(m.clip(RoundedCornerShape(16.dp)).background(bg).padding(vertical = 9.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(32.dp).clip(CircleShape).background(Color.White), Alignment.Center) { Icon(icon, null, tint = fg, modifier = Modifier.size(18.dp)) }
        Spacer(Modifier.height(4.dp))
        Text(label, color = fg, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold)
    }
}

/* ===================== ডোমেইন সার্চ ===================== */
@Composable
fun SearchScreen(initial: String) {
    val nav = LocalNav.current
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var q by remember { mutableStateOf(initial) }
    var active by remember { mutableStateOf(initial) }
    var tick by remember { mutableIntStateOf(0) }
    var busy by remember { mutableStateOf(false) }
    val res = if (active.isNotBlank()) load(active, "search", Api.q("q" to active), tick = tick) else null
    val home = load("home", "home")
    Screen {
        Row(Modifier.fillMaxWidth().height(56.dp).clip(RoundedCornerShape(18.dp)).background(C.Field).border(2.dp, C.Blue, RoundedCornerShape(18.dp)).padding(start = 14.dp, end = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(I.Search, null, tint = C.Blue, modifier = Modifier.size(22.dp)); Spacer(Modifier.width(8.dp))
            androidx.compose.foundation.text.BasicTextField(q, { q = it }, Modifier.weight(1f), singleLine = true,
                textStyle = androidx.compose.ui.text.TextStyle(color = C.Ink, fontSize = 15.sp),
                decorationBox = { inner -> if (q.isEmpty()) Text("yourname.com", color = C.Muted, fontSize = 15.sp); inner() })
            Btn("Search", { active = q.trim(); tick++ }, Modifier.width(96.dp), style = BtnStyle.Amber, h = 42.dp)
        }
        if (res == null) {
            Text("Popular extensions", color = C.Ink, fontSize = 16.sp, fontWeight = FontWeight.ExtraBold)
            Loaded(home) { j ->
                val a = j.getJSONArray("tlds")
                for (n in 0 until a.length()) { val t = a.getJSONObject(n)
                    RowCard(I.Globe, C.TileBlue, C.Blue, t.s("tld"), "Register", right = { Text(t.s("price_txt"), color = C.Blue, fontWeight = FontWeight.ExtraBold, fontSize = 14.sp) },
                        onClick = { q = "yourname" + t.s("tld") }) }
            }
        } else Loaded(res, { tick++ }) { j ->
            val a = j.getJSONArray("data")
            if (a.length() == 0) Empty("No results")
            for (n in 0 until a.length()) {
                val r = a.getJSONObject(n)
                val av = if (r.isNull("available")) null else r.optBoolean("available")
                RowCard(I.Globe, if (av == true) C.TileGreen else C.TileRose, if (av == true) C.Green else Color(0xFFB3261E), r.s("domain"),
                    when { av == true -> "Available · renews " + r.s("renew_txt"); av == false -> "Not available"; else -> "Could not check" },
                    right = {
                        if (av == true) Column(horizontalAlignment = Alignment.End) {
                            Text(r.s("price_txt"), color = C.Blue, fontWeight = FontWeight.ExtraBold, fontSize = 14.sp)
                            Spacer(Modifier.height(4.dp))
                            Btn("Register", { goSite(ctx, nav, scope, "search.php?q=" + r.s("domain")) { busy = it } }, Modifier.width(92.dp), style = BtnStyle.Blue, h = 34.dp)
                        } else Pill(if (av == false) "Taken" else "Unknown", C.TileRose, Color(0xFFB3261E)) })
            }
            if (!Session.loggedIn && a.length() > 0) Text("Log in to register a domain.", color = C.Muted, fontSize = 12.5.sp)
        }
    }
}

/* ===================== হোস্টিং প্ল্যান ===================== */
@Composable
fun PlansScreen() {
    val ctx = LocalContext.current; val nav = LocalNav.current; val scope = rememberCoroutineScope()
    var tick by remember { mutableIntStateOf(0) }
    val res = load("plans", "home", tick = tick)
    Screen {
        Loaded(res, { tick++ }) { j ->
            val a = j.getJSONArray("plans")
            for (n in 0 until a.length()) {
                val p = a.getJSONObject(n); val pop = p.optBoolean("popular")
                Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).border(if (pop) 2.dp else 1.5.dp, if (pop) C.Blue else C.Line, RoundedCornerShape(22.dp)).background(Color.White).padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Tile(I.Server, C.TileGreen, C.Green); Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) { Text(p.s("name"), color = C.Ink, fontSize = 16.sp, fontWeight = FontWeight.ExtraBold); Text(p.s("description"), color = C.Muted, fontSize = 12.sp, maxLines = 2) }
                        if (pop) Pill("Popular", C.Amber, Color(0xFF1B1300))
                    }
                    val f = p.getJSONArray("features")
                    Spacer(Modifier.height(10.dp))
                    for (k in 0 until f.length()) Row(Modifier.padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(I.Check, null, tint = C.Mint, modifier = Modifier.size(16.dp)); Spacer(Modifier.width(8.dp)); Text(f.getString(k), color = C.Ink, fontSize = 13.sp) }
                    Spacer(Modifier.height(12.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(p.s("price_txt"), color = C.Ink, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold)
                        Text(" / month", color = C.Muted, fontSize = 13.sp, modifier = Modifier.weight(1f))
                        if (p.s("status") == "coming_soon") Pill("Coming soon", C.TileAmber, C.Orange)
                        else Btn("Order now", { goSite(ctx, nav, scope, "hosting-order.php?plan=" + p.i("id")) }, Modifier.width(120.dp), style = if (pop) BtnStyle.Blue else BtnStyle.Amber, h = 42.dp)
                    }
                }
            }
            if (!Session.loggedIn) Text("Log in to order. Payment is completed in your browser on resellic.com.", color = C.Muted, fontSize = 12.5.sp)
        }
    }
}

/* ===================== সব সার্ভিস ===================== */
@Composable
fun AllServicesScreen() {
    val nav = LocalNav.current; val ctx = LocalContext.current
    val res = load("home", "home")
    Screen {
        BandCard("Our Services", I.Grid, "4 services") {
            val plans = res.json?.optJSONArray("plans")
            val first = plans?.let { if (it.length() > 0) it.getJSONObject(0) else null }
            val tl = res.json?.optJSONArray("tlds")
            val firstT = tl?.let { if (it.length() > 0) it.getJSONObject(0) else null }
            RowCard(I.Server, C.TileBlue, C.Blue, "Web Hosting", "Fast, secure hosting", right = {
                if (first != null) Text("from " + first.s("price_txt"), color = C.Blue, fontSize = 12.sp, fontWeight = FontWeight.ExtraBold); Spacer(Modifier.width(8.dp)); ArrowDot() }, onClick = { nav.tab("plans") })
            RowCard(I.Globe, C.TileGreen, C.Green, "Domains", "Register your name", right = {
                if (firstT != null) Text("from " + firstT.s("price_txt"), color = C.Blue, fontSize = 12.sp, fontWeight = FontWeight.ExtraBold); Spacer(Modifier.width(8.dp)); ArrowDot() }, onClick = { nav.tab("search") })
            RowCard(I.Shield, C.TileAmber, C.Orange, "SSL Certificates", "Trust for every visitor", right = { Pill("Soon", C.TileAmber, C.Orange) })
            RowCard(I.Cart, C.TileRose, C.Coral, "Digital Store", "Ready-made digital goods", right = { ArrowDot() }, onClick = { openUrl(ctx, SITE + "store.php") })
        }
        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(C.Blue).padding(horizontal = 18.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) { Text("Need help choosing?", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 15.sp); Text("Chat with our team", color = Color(0xD9FFFFFF), fontSize = 12.5.sp) }
            Btn("Chat now", { nav.tab("chat") }, Modifier.width(110.dp), style = BtnStyle.Amber, h = 40.dp)
        }
    }
}

/* ===================== মেনু (ভিজিটর) ===================== */
@Composable
fun MenuScreen() {
    val nav = LocalNav.current; val ctx = LocalContext.current
    Screen {
        BandCard("Menu", I.Menu) {
            MenuItem(I.Globe, C.TileGreen, C.Green, "Domains") { nav.tab("search") }
            MenuItem(I.Server, C.TileBlue, C.Blue, "Web Hosting") { nav.tab("plans") }
            MenuItem(I.Grid, C.TileAmber, C.Orange, "All Services") { nav.replace("all_services") }
            MenuItem(I.File, C.TileRose, C.Coral, "Blog") { nav.replace("posts") }
            MenuItem(I.Bolt, C.TileAmber, C.Orange, "Server Status") { openUrl(ctx, SITE + "status.php") }
        }
    }
}

@Composable
fun MenuItem(icon: androidx.compose.ui.graphics.vector.ImageVector, bg: Color, fg: Color, label: String, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 6.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Tile(icon, bg, fg, 36.dp); Spacer(Modifier.width(12.dp))
        Text(label, color = C.Ink, fontSize = 14.5.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.weight(1f))
        Icon(I.Chevron, null, tint = Color(0xFFA9B6D3), modifier = Modifier.size(18.dp))
    }
}

/* ===================== ব্লগ ===================== */
@Composable
fun PostsScreen() {
    val nav = LocalNav.current
    var tick by remember { mutableIntStateOf(0) }
    val res = load("posts", "posts", tick = tick)
    Screen(gap = 14.dp) {
        Loaded(res, { tick++ }) { j ->
            val a = j.getJSONArray("data")
            if (a.length() == 0) Empty("No posts yet")
            for (n in 0 until a.length()) {
                val p = a.getJSONObject(n)
                val shape = RoundedCornerShape(22.dp)
                Row(Modifier.fillMaxWidth().height(IntrinsicSize.Min).clip(shape).background(Color.White).border(1.dp, Color(0xFFDCE5F8), shape)
                    .clickable { nav.push("post", p.i("id").toString()) }) {
                    Box(Modifier.padding(vertical = 18.dp).width(5.dp).fillMaxHeight()
                        .background(Brush.verticalGradient(listOf(C.Blue, Color(0xFF3B82F6))), RoundedCornerShape(topEnd = 5.dp, bottomEnd = 5.dp)))
                    Column(Modifier.weight(1f).padding(start = 17.dp, end = 14.dp, top = 16.dp, bottom = 14.dp)) {
                        DateTag(p.s("date"), false)
                        Text(p.s("title"), color = C.Ink, fontSize = 16.5.sp, fontWeight = FontWeight.ExtraBold, lineHeight = 24.sp, modifier = Modifier.padding(top = 10.dp))
                        Row(Modifier.padding(top = 6.dp), verticalAlignment = Alignment.Bottom) {
                            Text(p.s("excerpt"), color = C.Muted, fontSize = 13.5.sp, lineHeight = 23.sp, maxLines = 2, modifier = Modifier.weight(1f))
                            Spacer(Modifier.width(10.dp)); ArrowDot()
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun DateTag(text: String, onBlue: Boolean) {
    Row(Modifier.clip(RoundedCornerShape(99.dp)).background(if (onBlue) Color(0x29FFFFFF) else C.TileBlue).padding(horizontal = 12.dp, vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(7.dp).clip(CircleShape).background(C.Amber)); Spacer(Modifier.width(7.dp))
        Text(text, color = if (onBlue) Color.White else C.Blue, fontSize = 12.sp, fontWeight = FontWeight.ExtraBold)
    }
}

@Composable
fun PostScreen(id: String) {
    var tick by remember { mutableIntStateOf(0) }
    val res = load(id, "post", Api.q("id" to id), tick = tick)
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Loaded(res, { tick++ }) { j ->
            val p = j.getJSONObject("post")
            Column(Modifier.fillMaxWidth().background(C.Blue).padding(start = 16.dp, end = 16.dp, bottom = 24.dp)) {
                DateTag(p.s("date"), true)
                Text(p.s("title"), color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, lineHeight = 33.sp, modifier = Modifier.padding(top = 12.dp))
            }
            Column(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 18.dp)) {
                val bl = p.optJSONArray("blocks")
                if (bl == null || bl.length() == 0) {
                    Text(p.s("text"), color = Color(0xFF17263D), fontSize = 15.5.sp, lineHeight = 28.sp)
                } else {
                    var num = 0
                    for (n in 0 until bl.length()) {
                        val b = bl.getJSONObject(n); val t = b.s("t"); val x = b.s("x")
                        if (t != "ol") num = 0
                        when (t) {
                            "h" -> Row(Modifier.padding(top = 18.dp, bottom = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                                Box(Modifier.size(width = 6.dp, height = 24.dp).clip(RoundedCornerShape(4.dp)).background(Brush.verticalGradient(listOf(Color(0xFF1E40AF), Color(0xFF3B82F6)))))
                                Spacer(Modifier.width(10.dp))
                                Text(x, color = C.Ink, fontSize = 17.5.sp, fontWeight = FontWeight.ExtraBold, lineHeight = 26.sp)
                            }
                            "li" -> Row(Modifier.fillMaxWidth().padding(vertical = 7.dp), verticalAlignment = Alignment.Top) {
                                Box(Modifier.padding(top = 3.dp).size(22.dp).clip(CircleShape).background(C.Blue), Alignment.Center) {
                                    Text("✓", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.ExtraBold) }
                                Spacer(Modifier.width(12.dp))
                                Text(x, color = Color(0xFF17263D), fontSize = 15.5.sp, lineHeight = 26.sp, modifier = Modifier.weight(1f))
                            }
                            "ol" -> { num++
                                Row(Modifier.fillMaxWidth().padding(vertical = 5.dp).clip(RoundedCornerShape(16.dp)).background(Color(0xFFF6F8FE)).padding(12.dp), verticalAlignment = Alignment.Top) {
                                    Box(Modifier.size(30.dp).clip(RoundedCornerShape(10.dp)).background(C.Blue), Alignment.Center) {
                                        Text(num.toString(), color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.ExtraBold) }
                                    Spacer(Modifier.width(12.dp))
                                    Text(x, color = Color(0xFF17263D), fontSize = 15.5.sp, lineHeight = 26.sp, modifier = Modifier.weight(1f).padding(top = 2.dp))
                                } }
                            else -> Text(x, color = Color(0xFF17263D), fontSize = 15.5.sp, lineHeight = 28.sp, modifier = Modifier.padding(bottom = 14.dp))
                        }
                    }
                }
            }
        }
    }
}

/* ===================== লগইন / রেজিস্টার / পাসওয়ার্ড ভুলে গেলে ===================== */
@Composable
private fun AuthFrame(title: String, sub: String, selected: Int, footer: @Composable () -> Unit = {}, content: @Composable ColumnScope.() -> Unit) {
    val nav = LocalNav.current
    Column(Modifier.fillMaxSize().background(Color.White).verticalScroll(rememberScrollState())) {
        Column(Modifier.fillMaxWidth().background(C.Blue).statusBarsPadding().padding(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 56.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                RoundBtn(I.Back, { if (!nav.back()) nav.tab("home") }, filled = true); Spacer(Modifier.width(12.dp)); Logo()
            }
            Spacer(Modifier.height(14.dp))
            Text(title, color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
            Text(sub, color = Color(0xD9FFFFFF), fontSize = 13.5.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(top = 3.dp))
        }
        Column(Modifier.offset(y = (-34).dp).padding(horizontal = 16.dp).fillMaxWidth()) {
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp)).border(1.5.dp, C.Line, RoundedCornerShape(28.dp))
                .background(Color.White).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                if (selected >= 0) Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(C.Canvas).padding(4.dp)) {
                    Seg("Log In", selected == 0, Modifier.weight(1f)) { nav.replaceAuth("login") }
                    Seg("Sign Up", selected == 1, Modifier.weight(1f)) { nav.replaceAuth("register") }
                }
                content()
            }
            Box(Modifier.fillMaxWidth().padding(vertical = 18.dp), Alignment.Center) { footer() }
        }
    }
}

fun Nav.replaceAuth(name: String) { if (top.name != name) { stack.clear(); stack.add(Route(name)) } }

@Composable
private fun Seg(text: String, on: Boolean, m: Modifier, onClick: () -> Unit) {
    Box(m.height(40.dp).clip(RoundedCornerShape(12.dp)).background(if (on) C.Blue else Color.Transparent).clickable(onClick = onClick), Alignment.Center) {
        Text(text, color = if (on) Color.White else C.Muted, fontWeight = FontWeight.ExtraBold, fontSize = 13.5.sp) }
}

@Composable
fun LoginScreen() {
    val nav = LocalNav.current; val scope = rememberCoroutineScope()
    var email by remember { mutableStateOf("") }; var pass by remember { mutableStateOf("") }
    var err by remember { mutableStateOf<String?>(null) }; var busy by remember { mutableStateOf(false) }
    AuthFrame("Welcome back", "Log in to manage your domains and services", 0, footer = {
        Text(buildAnnotatedString { append("New to Resellic? "); withStyle(SpanStyle(color = C.Blue, fontWeight = FontWeight.ExtraBold)) { append("Create an account") } },
            color = C.Muted, fontSize = 13.5.sp, modifier = Modifier.clickable { nav.replaceAuth("register") })
    }) {
        Field("Email", email, { email = it }, I.Mail, keyboard = KeyboardType.Email, placeholder = "you@example.com")
        Field("Password", pass, { pass = it }, I.Lock, password = true)
        Row(Modifier.fillMaxWidth(), Arrangement.End) {
            Text("Forgot password?", color = C.Blue, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.clickable { nav.push("forgot") })
        }
        ErrorText(err)
        Btn(if (busy) "Please wait…" else "Log In", {
            busy = true; err = null
            scope.launch {
                val j = Api.call("login", "", JSONObject().put("email", email.trim()).put("password", pass).put("device_id", Session.deviceId()).put("device_name", Session.deviceName()))
                busy = false
                if (j.optBoolean("ok")) Session.save(j.s("token"), j.optJSONObject("user")) else err = j.s("error", "Could not log in")
            }
        }, Modifier.fillMaxWidth(), h = 52.dp, enabled = !busy && email.isNotBlank() && pass.isNotEmpty())
    }
}

@Composable
fun RegisterScreen() {
    val nav = LocalNav.current; val scope = rememberCoroutineScope()
    var f by remember { mutableStateOf("") }; var l by remember { mutableStateOf("") }; var e by remember { mutableStateOf("") }
    var ph by remember { mutableStateOf("") }; var pw by remember { mutableStateOf("") }
    var ad by remember { mutableStateOf("") }; var ci by remember { mutableStateOf("") }; var pc by remember { mutableStateOf("") }; var co by remember { mutableStateOf("BD") }
    var err by remember { mutableStateOf<String?>(null) }; var busy by remember { mutableStateOf(false) }
    val score = (if (pw.length >= 8) 1 else 0) + (if (pw.any { it.isUpperCase() } && pw.any { it.isLowerCase() }) 1 else 0) +
        (if (pw.any { it.isDigit() }) 1 else 0) + (if (pw.any { !it.isLetterOrDigit() }) 1 else 0)
    AuthFrame("Create account", "Join Resellic in under a minute", 1, footer = {
        Text(buildAnnotatedString { append("Already have an account? "); withStyle(SpanStyle(color = C.Blue, fontWeight = FontWeight.ExtraBold)) { append("Log in") } },
            color = C.Muted, fontSize = 13.5.sp, modifier = Modifier.clickable { nav.replaceAuth("login") })
    }) {
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Field("First name", f, { f = it }, I.Person, modifier = Modifier.weight(1f))
            Field("Last name", l, { l = it }, I.Person, modifier = Modifier.weight(1f))
        }
        Field("Email", e, { e = it }, I.Mail, keyboard = KeyboardType.Email)
        Field("Phone", ph, { ph = it }, I.Headset, keyboard = KeyboardType.Phone, placeholder = "01XXXXXXXXX")
        Field("Address", ad, { ad = it }, I.Home)
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Field("City", ci, { ci = it }, modifier = Modifier.weight(1f))
            Field("Post code", pc, { pc = it }, keyboard = KeyboardType.Number, modifier = Modifier.weight(1f))
        }
        Field("Country (2 letters)", co, { co = it.take(2).uppercase() }, I.Globe)
        Field("Password (8+ characters)", pw, { pw = it }, I.Lock, password = true)
        if (pw.isNotEmpty()) {
            val col = when { score <= 1 -> Color(0xFFD93025); score == 2 -> C.Orange; else -> Color(0xFF16A34A) }
            Column {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    for (n in 1..4) Box(Modifier.weight(1f).height(5.dp).clip(RoundedCornerShape(5.dp)).background(if (n <= score) col else Color(0xFFE2E8F5)))
                }
                Text(when { score <= 1 -> "Weak password"; score == 2 -> "Fair password"; score == 3 -> "Good password"; else -> "Strong password" },
                    color = col, fontSize = 12.5.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.padding(top = 6.dp))
            }
        }
        ErrorText(err)
        Text(buildAnnotatedString { append("I agree to the "); withStyle(SpanStyle(color = C.Blue, fontWeight = FontWeight.ExtraBold)) { append("Terms") }; append(" and ")
            withStyle(SpanStyle(color = C.Blue, fontWeight = FontWeight.ExtraBold)) { append("Privacy Policy") } }, color = C.Muted, fontSize = 12.sp)
        Btn(if (busy) "Please wait…" else "Create account", {
            busy = true; err = null
            scope.launch {
                val j = Api.call("register", "", JSONObject().put("first_name", f.trim()).put("last_name", l.trim()).put("email", e.trim()).put("phone", ph.trim())
                    .put("address1", ad.trim()).put("city", ci.trim()).put("postcode", pc.trim()).put("country", co.trim())
                    .put("password", pw).put("device_id", Session.deviceId()).put("device_name", Session.deviceName()))
                busy = false
                if (j.optBoolean("ok")) Session.save(j.s("token"), j.optJSONObject("user")) else err = j.s("error", "Could not create the account")
            }
        }, Modifier.fillMaxWidth(), style = BtnStyle.Amber, h = 52.dp, enabled = !busy && f.isNotBlank() && e.isNotBlank() && pw.length >= 8)
    }
}

@Composable
fun ForgotScreen() {
    val scope = rememberCoroutineScope()
    var email by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf<String?>(null) }; var busy by remember { mutableStateOf(false) }
    AuthFrame("Reset password", "We will email you a reset link", -1) {
        Field("Email", email, { email = it }, I.Mail, keyboard = KeyboardType.Email)
        if (msg != null) Text(msg!!, color = C.Green, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
        Btn(if (busy) "Please wait…" else "Send reset link", {
            busy = true
            scope.launch { val j = Api.call("forgot", "", JSONObject().put("email", email.trim())); busy = false; msg = j.s("message", j.s("error")) }
        }, Modifier.fillMaxWidth(), h = 52.dp, enabled = !busy && email.isNotBlank())
    }
}
