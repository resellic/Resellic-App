package com.resellic.client

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import org.json.JSONObject

fun daysLeft(date: String): String {
    if (date.length < 10) return ""
    return try {
        val d = java.time.LocalDate.parse(date.substring(0, 10)); val n = java.time.temporal.ChronoUnit.DAYS.between(java.time.LocalDate.now(), d)
        if (n < 0) "Expired" else if (n == 0L) "Expires today" else "Expires in $n days"
    } catch (_: Exception) { "Expires " + date.substring(0, 10) }
}

/* ===================== হোম (লগইন করা) ===================== */
@Composable
fun UserHome() {
    val nav = LocalNav.current; val ctx = LocalContext.current; val scope = rememberCoroutineScope()
    var tick by remember { mutableIntStateOf(0) }
    val res = load("dash", "dashboard", auth = true, tick = tick)
    LaunchedEffect(res.json) { res.json?.optJSONObject("user")?.let { Session.updateUser(it) } }
    Screen(gap = 12.dp) {
        Loaded(res, { tick++ }) { j ->
            val u = j.getJSONObject("user"); val st = j.getJSONObject("stats")
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(46.dp).clip(CircleShape).background(C.Ink), Alignment.Center) { Text(u.s("first_name").take(1).uppercase(), color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp) }
                Spacer(Modifier.width(12.dp))
                Column { Text("Hello, " + u.s("first_name"), color = C.Ink, fontSize = 19.sp, fontWeight = FontWeight.ExtraBold); Text("Here is your account today", color = C.Muted, fontSize = 12.5.sp) }
            }
            // ওয়ালেট কার্ড
            Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp)).background(C.Blue)) {
                Box(Modifier.align(Alignment.TopEnd).offset(x = 12.dp, y = (-26).dp).size(90.dp).clip(CircleShape).background(C.Amber))
                Column(Modifier.padding(18.dp)) {
                    Text("Wallet balance", color = Color(0xD9FFFFFF), fontSize = 12.5.sp, fontWeight = FontWeight.Bold)
                    Text(j.s("balance_txt"), color = Color.White, fontSize = 32.sp, fontWeight = FontWeight.ExtraBold)
                    Spacer(Modifier.height(12.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Btn("Add funds", { nav.push("wallet") }, Modifier.weight(1f), style = BtnStyle.Amber, h = 46.dp, icon = I.Plus)
                        Btn(if (st.i("unpaid_count") > 0) "Pay due " + j.s("unpaid_txt") else "No dues", { nav.tab("billing") }, Modifier.weight(1f), style = BtnStyle.Soft, h = 46.dp)
                    }
                }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Stat(I.Server, C.TileBlue, C.Blue, "Services", st.i("services").toString(), Modifier.weight(1f)) { nav.tab("services") }
                Stat(I.Globe, C.TileGreen, C.Green, "Domains", st.i("domains").toString(), Modifier.weight(1f)) { nav.tab("domains") }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Stat(I.Receipt, C.TileAmber, C.Orange, "Unpaid", st.i("unpaid_count").toString(), Modifier.weight(1f)) { nav.tab("billing") }
                Stat(I.Ticket, C.TileRose, C.Coral, "Tickets", st.i("open_tickets").toString(), Modifier.weight(1f)) { nav.push("tickets") }
            }
            val urgent = j.getJSONArray("urgent")
            if (urgent.length() > 0) {
                val x = urgent.getJSONObject(0)
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(C.TileRose).border(1.5.dp, Color(0xFFE99A8E), RoundedCornerShape(16.dp))
                    .clickable { nav.push("domain", x.i("id").toString()) }.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(x.s("domain") + " — " + daysLeft(x.s("expires_at")).lowercase(), color = Color(0xFF8A1C12), fontWeight = FontWeight.ExtraBold, fontSize = 13.5.sp)
                        Text(if (x.i("auto_renew") == 1) "Auto-renew is on" else "Auto-renew is off", color = Color(0xFF8A1C12), fontSize = 12.sp)
                    }
                    Btn("Renew", { scope.launch { val r = Api.call("domain_do", "", JSONObject().put("id", x.i("id").toString()).put("do", "renew").put("years", "1"), true); if (r.optBoolean("ok") && r.i("invoice_id") > 0) nav.push("invoice", r.i("invoice_id").toString()) else nav.push("domain", x.i("id").toString()) } }, Modifier.width(84.dp), h = 36.dp)
                }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Quick(I.Globe, C.TileBlue, C.Blue, "Register", Modifier.weight(1f)) { nav.tab("search") }
                Quick(I.Server, C.TileGreen, C.Green, "Hosting", Modifier.weight(1f)) { nav.tab("plans") }
                Quick(I.Receipt, C.TileAmber, C.Orange, "Pay bill", Modifier.weight(1f)) { nav.tab("billing") }
                Quick(I.Cart, C.TileViolet, Color(0xFF5B3FD0), "Store", Modifier.weight(1f)) { nav.push("store") }
            }
            Spacer(Modifier.height(70.dp))
        }
    }
}

@Composable
private fun Stat(icon: androidx.compose.ui.graphics.vector.ImageVector, bg: Color, fg: Color, label: String, value: String, m: Modifier, onClick: () -> Unit) {
    Row(m.clip(RoundedCornerShape(20.dp)).background(bg).clickable(onClick = onClick).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(38.dp).clip(RoundedCornerShape(12.dp)).background(Color.White), Alignment.Center) { Icon(icon, null, tint = fg, modifier = Modifier.size(20.dp)) }
        Spacer(Modifier.width(10.dp))
        Column { Text(label, color = fg, fontSize = 12.sp, fontWeight = FontWeight.Bold); Text(value, color = C.Ink, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold) }
    }
}

@Composable
private fun Quick(icon: androidx.compose.ui.graphics.vector.ImageVector, bg: Color, fg: Color, label: String, m: Modifier, onClick: () -> Unit) {
    Column(m.clip(RoundedCornerShape(18.dp)).border(1.5.dp, C.Line, RoundedCornerShape(18.dp)).clickable(onClick = onClick).padding(vertical = 10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Tile(icon, bg, fg, 38.dp); Spacer(Modifier.height(5.dp))
        Text(label, color = C.Ink, fontSize = 11.5.sp, fontWeight = FontWeight.ExtraBold)
    }
}

/* ===================== ডোমেইন ===================== */
@Composable
fun DomainsScreen() {
    val nav = LocalNav.current; val ctx = LocalContext.current; val scope = rememberCoroutineScope()
    var q by remember { mutableStateOf("") }
    var tick by remember { mutableIntStateOf(0) }
    val res = load(q, "domains", Api.q("q" to q), true, tick)
    Screen {
        BandCard("My Domains", I.Globe, "Add New", { nav.tab("search") }) {
            Field("", q, { q = it }, I.Search, placeholder = "Search domains")
            Loaded(res, { tick++ }) { j ->
                val a = j.getJSONArray("data")
                if (a.length() == 0) Empty("No domains yet")
                for (n in 0 until a.length()) {
                    val d = a.getJSONObject(n)
                    RowCard(I.Globe, C.TileBlue, C.Blue, d.s("domain"), daysLeft(d.s("expires_at")), right = { StatusPill(d.s("status")) },
                        onClick = { nav.push("domain", d.i("id").toString()) })
                }
            }
        }
        Spacer(Modifier.height(70.dp))
    }
}

@Composable
fun DomainDetailScreen(id: String) {
    val nav = LocalNav.current; val ctx = LocalContext.current; val scope = rememberCoroutineScope()
    var tick by remember { mutableIntStateOf(0) }
    val res = load(id, "domain", Api.q("id" to id), true, tick)
    Screen {
        Loaded(res, { tick++ }) { j ->
            val d = j.getJSONObject("domain")
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(C.Blue).padding(18.dp)) {
                Text(d.s("domain"), color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
                Spacer(Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { StatusPill(d.s("status")); Pill(daysLeft(d.s("expires_at")), Color(0x29FFFFFF), Color.White) }
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Btn("Renew", { scope.launch { val r = Api.call("domain_do", "", JSONObject().put("id", id).put("do", "renew").put("years", "1"), true); if (r.optBoolean("ok") && r.i("invoice_id") > 0) nav.push("invoice", r.i("invoice_id").toString()) else nav.push("manage", id) } }, Modifier.weight(1f), style = BtnStyle.Amber, h = 46.dp)
                    Btn("Manage", { nav.push("manage", id) }, Modifier.weight(1f), style = BtnStyle.Soft, h = 46.dp)
                }
            }
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).border(1.5.dp, C.Line, RoundedCornerShape(20.dp)).padding(horizontal = 16.dp, vertical = 6.dp)) {
                KV("Expires", d.s("expires_at").take(10)); KV("Registered", d.s("registered_at").take(10))
                KV("Auto-renew", if (d.i("auto_renew") == 1) "On" else "Off")
                if (d.s("renew_txt").isNotEmpty()) KV("Renewal price", d.s("renew_txt") + " / year")
            }
            val ns = j.getJSONArray("nameservers")
            if (ns.length() > 0) BandCard("Nameservers", I.Server) { for (k in 0 until ns.length()) Text(ns.getString(k), color = C.Ink, fontSize = 13.5.sp, modifier = Modifier.padding(8.dp)) }
            val dns = j.getJSONArray("dns")
            if (dns.length() > 0) BandCard("DNS records", I.Grid, dns.length().toString()) {
                for (k in 0 until dns.length()) { val r = dns.getJSONObject(k)
                    Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp), verticalAlignment = Alignment.Top) {
                        Pill(r.s("type"), C.TileBlue, C.Blue); Spacer(Modifier.width(8.dp))
                        Column { Text(r.s("host").ifEmpty { "@" }, color = C.Ink, fontWeight = FontWeight.Bold, fontSize = 13.sp); Text(r.s("value"), color = C.Muted, fontSize = 12.sp) }
                    } }
            }
        }
    }
}

/* ===================== সার্ভিস (হোস্টিং) ===================== */
@Composable
fun ServicesScreen() {
    val nav = LocalNav.current; val ctx = LocalContext.current; val scope = rememberCoroutineScope()
    var tick by remember { mutableIntStateOf(0) }
    var f by remember { mutableStateOf("all") }
    val res = load("services", "services", "", true, tick)
    Screen {
        BandCard("My Services", I.Grid, "Order hosting", { nav.tab("plans") }) {
            Loaded(res, { tick++ }) { j ->
                val a = j.getJSONArray("data")
                val kinds = listOf("all" to "All", "hosting" to "Hosting", "digital" to "Digital")
                Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    kinds.forEach { (k, label) ->
                        val n = (0 until a.length()).count { k == "all" || a.getJSONObject(it).s("kind") == k }
                        if (k == "all" || n > 0) Box(Modifier.clip(RoundedCornerShape(50)).background(if (f == k) C.Ink else Color.White)
                            .border(1.dp, C.Line, RoundedCornerShape(50)).clickable { f = k }.padding(horizontal = 14.dp, vertical = 8.dp)) {
                            Text("$label $n", color = if (f == k) Color.White else C.Ink, fontSize = 13.sp, fontWeight = FontWeight.Bold) }
                    }
                }
                Spacer(Modifier.height(10.dp))
                var shown = 0
                for (n in 0 until a.length()) {
                    val s = a.getJSONObject(n); val kind = s.s("kind")
                    if (f != "all" && kind != f) continue
                    shown++
                    val ic = if (kind == "hosting") I.Server else I.Cart
                    val (tile, fg) = when (kind) { "hosting" -> C.TileGreen to C.Green; else -> C.TileViolet to Color(0xFF5B3FD0) }
                    RowCard(ic, tile, fg, s.s("name"), s.s("sub"), right = { StatusPill(s.s("status")) },
                        onClick = { if (kind == "hosting") nav.push("hosting", s.i("id").toString()) else nav.push("products") })
                }
                if (shown == 0) Empty("You have no services yet")
            }
        }
        Spacer(Modifier.height(70.dp))
    }
}

@Composable
fun HostingDetailScreen(id: String) {
    val nav = LocalNav.current; val ctx = LocalContext.current; val scope = rememberCoroutineScope()
    var tick by remember { mutableIntStateOf(0) }
    val res = load(id, "hosting_one", Api.q("id" to id), true, tick)
    Screen {
        Loaded(res, { tick++ }) { j ->
            val h = j.getJSONObject("hosting")
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(C.Blue).padding(18.dp)) {
                Text(h.s("plan_name").ifEmpty { "Hosting" }, color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.ExtraBold)
                Text(h.s("domain"), color = Color(0xD9FFFFFF), fontSize = 13.sp)
                Spacer(Modifier.height(8.dp)); StatusPill(h.s("status")); Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Btn("Open cPanel", { scope.launch { val r = Api.call("hosting_do", "", JSONObject().put("id", id).put("do", "cpanel"), true); if (r.optBoolean("ok")) nav.push("web", "url:" + r.s("url")) } }, Modifier.weight(1f), style = BtnStyle.Amber, h = 46.dp)
                    Btn("Renew", { scope.launch { val r = Api.call("hosting_do", "", JSONObject().put("id", id).put("do", "renew"), true); if (r.optBoolean("ok") && r.i("invoice_id") > 0) nav.push("invoice", r.i("invoice_id").toString()) } }, Modifier.weight(1f), style = BtnStyle.Soft, h = 46.dp)
                }
            }
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).border(1.5.dp, C.Line, RoundedCornerShape(20.dp)).padding(horizontal = 16.dp, vertical = 6.dp)) {
                KV("Username", h.s("username").ifEmpty { "—" }); KV("Billing", h.s("amount_txt") + " / " + (if (h.s("billing_cycle") == "yearly") "year" else "month"))
                KV("Next due", h.s("next_due").take(10).ifEmpty { "—" }); KV("Activated", h.s("activated_at").take(10).ifEmpty { "—" })
                val ns = h.optJSONArray("ns"); if (ns != null && ns.length() > 0) for (k in 0 until ns.length()) KV("Nameserver " + (k + 1), ns.getString(k))
            }
            HostingActions(id, h.s("status")) { tick++ }
        }
    }
}

/* ===================== বিলিং ===================== */
@Composable
fun BillingScreen() {
    val nav = LocalNav.current
    var tick by remember { mutableIntStateOf(0) }
    val res = load("invoices", "invoices", "", true, tick)
    val dash = load("dash2", "dashboard", "", true, tick)
    Screen {
        Loaded(dash) { d ->
            val st = d.getJSONObject("stats")
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(26.dp)).background(C.Blue).padding(18.dp)) {
                Text("Total due", color = Color(0xD9FFFFFF), fontSize = 12.5.sp, fontWeight = FontWeight.Bold)
                Text(d.s("unpaid_txt"), color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold)
                Text(st.i("unpaid_count").toString() + " unpaid invoices", color = Color(0xD9FFFFFF), fontSize = 12.5.sp)
            }
        }
        BandCard("Invoices", I.Receipt) {
            Loaded(res, { tick++ }) { j ->
                val a = j.getJSONArray("data")
                if (a.length() == 0) Empty("No invoices yet")
                for (n in 0 until a.length()) {
                    val x = a.getJSONObject(n)
                    RowCard(I.Receipt, C.TileAmber, C.Orange, x.s("invoice_no"), "Due " + x.s("due_date").take(10),
                        right = { Column(horizontalAlignment = Alignment.End) { Text(x.s("total_txt"), color = C.Ink, fontWeight = FontWeight.ExtraBold, fontSize = 13.5.sp); Spacer(Modifier.height(3.dp)); StatusPill(x.s("status")) } },
                        onClick = { nav.push("invoice", x.i("id").toString()) })
                }
            }
        }
        Spacer(Modifier.height(70.dp))
    }
}

@Composable
fun InvoiceScreen(id: String) {
    val nav = LocalNav.current; val ctx = LocalContext.current; val scope = rememberCoroutineScope()
    var tick by remember { mutableIntStateOf(0) }
    val res = load(id, "invoice", Api.q("id" to id), true, tick)
    var msg by remember { mutableStateOf<String?>(null) }; var err by remember { mutableStateOf<String?>(null) }; var busy by remember { mutableStateOf(false) }
    Screen {
        Loaded(res, { tick++ }) { j ->
            val v = j.getJSONObject("invoice"); val unpaid = v.s("status") == "unpaid"
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(C.Blue).padding(18.dp)) {
                Text(v.s("invoice_no"), color = Color(0xD9FFFFFF), fontSize = 13.sp, fontWeight = FontWeight.Bold)
                Text(v.s("total_txt"), color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold)
                Spacer(Modifier.height(6.dp)); StatusPill(v.s("status"))
            }
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).border(1.5.dp, C.Line, RoundedCornerShape(20.dp)).padding(horizontal = 16.dp, vertical = 6.dp)) {
                val lines = j.getJSONArray("items")
                for (k in 0 until lines.length()) { val x = lines.getJSONObject(k); KV(x.s("description"), x.s("amount_txt")) }
                KV("Due date", v.s("due_date").take(10))
            }
            if (msg != null) Text(msg!!, color = C.Green, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            ErrorText(err)
            if (unpaid) InvoicePayBlock(id) { msg = "Paid. Thank you!"; tick++ }
        }
    }
}

/* ===================== অ্যাকাউন্ট ===================== */
@Composable
fun AccountScreen() {
    val nav = LocalNav.current; val ctx = LocalContext.current; val scope = rememberCoroutineScope()
    val u = Session.user
    Screen {
        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).border(1.5.dp, C.Line, RoundedCornerShape(22.dp)).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(52.dp).clip(CircleShape).background(C.Ink), Alignment.Center) { Text((u?.s("first_name") ?: "?").take(1).uppercase(), color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 20.sp) }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(((u?.s("first_name") ?: "") + " " + (u?.s("last_name") ?: "")).trim(), color = C.Ink, fontSize = 16.sp, fontWeight = FontWeight.ExtraBold)
                Text(u?.s("email") ?: "", color = C.Muted, fontSize = 12.sp); Text(u?.s("phone") ?: "", color = C.Muted, fontSize = 12.sp)
            }
            Btn("Edit", { nav.push("profile") }, Modifier.width(64.dp), style = BtnStyle.Out, h = 36.dp)
        }
        BandCard("Account", I.Person) {
            MenuItem(I.Ticket, C.TileRose, C.Coral, "Support tickets") { nav.push("tickets") }
            MenuItem(I.Chat, C.TileBlue, C.Blue, "Live chat") { nav.push("chat") }
            MenuItem(I.Wallet, C.TileAmber, C.Orange, "Wallet & add funds") { nav.push("wallet") }
            MenuItem(I.Lock, C.TileGreen, C.Green, "Change password") { nav.push("password") }
            MenuItem(I.Gift, C.TileViolet, Color(0xFF5B3FD0), "Referral") { nav.push("referral") }
            MenuItem(I.Cart, C.TileViolet, Color(0xFF5B3FD0), "Digital store") { nav.push("store") }
            MenuItem(I.File, C.TileBlue, C.Blue, "My products") { nav.push("products") }
            MenuItem(I.Globe, C.TileGreen, C.Green, "Transfer a domain") { nav.push("transfer") }
            MenuItem(I.Bolt, C.TileAmber, C.Orange, "Server status") { nav.push("status") }
        }
        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(C.TileRose).clickable {
            scope.launch { Api.call("logout", "", JSONObject(), true); Session.clear() }
        }.padding(vertical = 14.dp), Arrangement.Center, Alignment.CenterVertically) {
            Icon(I.Logout, null, tint = Color(0xFFB3261E), modifier = Modifier.size(20.dp)); Spacer(Modifier.width(8.dp))
            Text("Log out", color = Color(0xFFB3261E), fontWeight = FontWeight.ExtraBold, fontSize = 15.sp)
        }
        Spacer(Modifier.height(70.dp))
    }
}

@Composable
fun ProfileScreen() {
    val nav = LocalNav.current; val scope = rememberCoroutineScope(); val u = Session.user
    var f by remember { mutableStateOf(u?.s("first_name") ?: "") }; var l by remember { mutableStateOf(u?.s("last_name") ?: "") }; var p by remember { mutableStateOf(u?.s("phone") ?: "") }
    var err by remember { mutableStateOf<String?>(null) }; var busy by remember { mutableStateOf(false) }
    Screen {
        Field("First name", f, { f = it }, I.Person); Field("Last name", l, { l = it }, I.Person)
        Field("Phone", p, { p = it }, I.Headset, keyboard = androidx.compose.ui.text.input.KeyboardType.Phone)
        Text("Email: " + (u?.s("email") ?: ""), color = C.Muted, fontSize = 13.sp)
        ErrorText(err)
        Btn(if (busy) "Saving…" else "Save", {
            busy = true
            scope.launch {
                val j = Api.call("profile_save", "", JSONObject().put("first_name", f).put("last_name", l).put("phone", p), true); busy = false
                if (j.optBoolean("ok")) { Session.updateUser(j.optJSONObject("user")); nav.back() } else err = j.s("error")
            }
        }, Modifier.fillMaxWidth(), h = 52.dp, enabled = !busy && f.isNotBlank())
    }
}

@Composable
fun PasswordScreen() {
    val nav = LocalNav.current; val scope = rememberCoroutineScope()
    var o by remember { mutableStateOf("") }; var n by remember { mutableStateOf("") }
    var err by remember { mutableStateOf<String?>(null) }; var busy by remember { mutableStateOf(false) }
    Screen {
        Field("Current password", o, { o = it }, I.Lock, password = true)
        Field("New password (8+ characters)", n, { n = it }, I.Lock, password = true)
        ErrorText(err)
        Btn(if (busy) "Saving…" else "Change password", {
            busy = true
            scope.launch {
                val j = Api.call("password_change", "", JSONObject().put("old", o).put("new", n), true); busy = false
                if (j.optBoolean("ok")) { Session.save(j.s("token"), Session.user); nav.back() } else err = j.s("error")
            }
        }, Modifier.fillMaxWidth(), h = 52.dp, enabled = !busy && o.isNotEmpty() && n.length >= 8)
    }
}

@Composable
fun WalletScreen() {
    val nav = LocalNav.current; val ctx = LocalContext.current; val scope = rememberCoroutineScope()
    var tick by remember { mutableIntStateOf(0) }
    val res = load("wallet", "wallet", "", true, tick)
    var addAmt by remember { mutableStateOf("1000") }; var addErr by remember { mutableStateOf<String?>(null) }; var addBusy by remember { mutableStateOf(false) }
    Screen {
        Loaded(res, { tick++ }) { j ->
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(26.dp)).background(C.Blue).padding(18.dp)) {
                Text("Wallet balance", color = Color(0xD9FFFFFF), fontSize = 12.5.sp, fontWeight = FontWeight.Bold)
                Text(j.s("balance_txt"), color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold)
                Spacer(Modifier.height(12.dp))
            }
            Card {
                SectionTitle("Add funds")
                Field("Amount (min 10)", addAmt, { addAmt = it.filter { c -> c.isDigit() } }, keyboard = androidx.compose.ui.text.input.KeyboardType.Number, placeholder = "1000")
                ErrorText(addErr)
                Btn(if (addBusy) "Please wait…" else "Create invoice", {
                    addBusy = true; addErr = null
                    scope.launch {
                        val r = Api.call("wallet_add", "", JSONObject().put("amount", addAmt), true); addBusy = false
                        if (r.optBoolean("ok")) nav.push("invoice", r.i("invoice_id").toString()) else addErr = r.s("error")
                    }
                }, Modifier.fillMaxWidth(), style = BtnStyle.Amber, h = 48.dp, enabled = !addBusy && (addAmt.toIntOrNull() ?: 0) >= 10, icon = I.Plus)
            }
            val h = j.optJSONArray("history")
            if (h != null && h.length() > 0) BandCard("History", I.Receipt) {
                for (k in 0 until h.length()) { val x = h.getJSONObject(k)
                    val amt = x.d("amount")
                    RowCard(I.Wallet, if (amt >= 0) C.TileGreen else C.TileRose, if (amt >= 0) C.Green else Color(0xFFB3261E),
                        x.s("note").ifEmpty { x.s("type").replace('_', ' ').replaceFirstChar { ch -> ch.uppercase() } }, x.s("created_at").take(10),
                        right = { Text((if (amt >= 0) "+" else "") + amt.toString(), color = if (amt >= 0) C.Green else Color(0xFFB3261E), fontWeight = FontWeight.ExtraBold, fontSize = 13.5.sp) }) }
            }
        }
    }
}

/* ===================== সাপোর্ট টিকেট ===================== */
@Composable
fun TicketsScreen() {
    val nav = LocalNav.current
    var tick by remember { mutableIntStateOf(0) }
    val res = load("tickets", "tickets", "", true, tick)
    Screen {
        Btn("New ticket", { nav.push("ticket_new") }, Modifier.fillMaxWidth(), style = BtnStyle.Blue, h = 48.dp, icon = I.Plus)
        Loaded(res, { tick++ }) { j ->
            val a = j.getJSONArray("data")
            if (a.length() == 0) Empty("No tickets yet")
            for (n in 0 until a.length()) { val t = a.getJSONObject(n)
                RowCard(I.Ticket, C.TileRose, C.Coral, t.s("subject"), t.s("ticket_no") + " · " + t.s("updated_at").take(10), right = { StatusPill(t.s("status")) },
                    onClick = { nav.push("ticket", t.i("id").toString()) }) }
        }
    }
}

@Composable
fun TicketScreen(id: String) {
    val scope = rememberCoroutineScope()
    var tick by remember { mutableIntStateOf(0) }
    val res = load(id, "ticket", Api.q("id" to id), true, tick)
    var text by remember { mutableStateOf("") }; var busy by remember { mutableStateOf(false) }; var err by remember { mutableStateOf<String?>(null) }
    Screen {
        Loaded(res, { tick++ }) { j ->
            val t = j.getJSONObject("ticket")
            Text(t.s("subject"), color = C.Ink, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { Pill(t.s("ticket_no"), C.TileBlue, C.Blue); StatusPill(t.s("status")) }
            val r = j.getJSONArray("replies")
            for (k in 0 until r.length()) { val m = r.getJSONObject(k); val staff = m.i("is_staff") == 1
                Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(if (staff) Color.White else C.TileBlue)
                    .border(1.5.dp, if (staff) C.Line else Color.Transparent, RoundedCornerShape(16.dp)).padding(12.dp)) {
                    Text(if (staff) "Support team" else "You", color = if (staff) C.Blue else C.Muted, fontSize = 11.5.sp, fontWeight = FontWeight.ExtraBold)
                    Text(m.s("message"), color = C.Ink, fontSize = 14.sp, modifier = Modifier.padding(top = 3.dp))
                    Text(m.s("created_at").take(16), color = C.Muted, fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp)) } }
            if (t.s("status") != "closed") {
                Field("Reply", text, { text = it }, singleLine = false)
                ErrorText(err)
                Btn(if (busy) "Sending…" else "Send reply", {
                    busy = true; err = null
                    scope.launch {
                        val x = Api.call("ticket_reply", "", JSONObject().put("id", id).put("message", text), true); busy = false
                        if (x.optBoolean("ok")) { text = ""; tick++ } else err = x.s("error")
                    }
                }, Modifier.fillMaxWidth(), h = 48.dp, enabled = !busy && text.isNotBlank(), icon = I.Send)
            }
        }
    }
}

@Composable
fun NewTicketScreen() {
    val nav = LocalNav.current; val scope = rememberCoroutineScope()
    var sub by remember { mutableStateOf("") }; var msg by remember { mutableStateOf("") }
    var err by remember { mutableStateOf<String?>(null) }; var busy by remember { mutableStateOf(false) }
    Screen {
        Field("Subject", sub, { sub = it }, I.Ticket)
        Field("Message", msg, { msg = it }, singleLine = false)
        ErrorText(err)
        Btn(if (busy) "Sending…" else "Open ticket", {
            busy = true; err = null
            scope.launch {
                val x = Api.call("ticket_new", "", JSONObject().put("subject", sub).put("message", msg), true); busy = false
                if (x.optBoolean("ok")) nav.replace("ticket", x.i("id").toString()) else err = x.s("error")
            }
        }, Modifier.fillMaxWidth(), h = 52.dp, enabled = !busy && sub.isNotBlank() && msg.isNotBlank())
    }
}


/* ===================== নোটিফিকেশন ===================== */
@Composable
fun NotificationsScreen() {
    val scope = rememberCoroutineScope()
    var tick by remember { mutableIntStateOf(0) }
    val res = load("notifs", "notifications", auth = true, tick = tick)
    Screen(gap = 10.dp) {
        Loaded(res, { tick++ }) { j ->
            val a = j.getJSONArray("data")
            if (j.i("unread") > 0) Btn("Mark all as read", { scope.launch { Api.call("notif_read", "", JSONObject(), true); tick++ } }, Modifier.fillMaxWidth(), style = BtnStyle.Soft, h = 44.dp)
            if (a.length() == 0) Empty("No notifications yet")
            for (n in 0 until a.length()) {
                val o = a.getJSONObject(n)
                val unread = !o.optBoolean("read")
                val (icon, bg, fg) = when (o.s("category")) {
                    "payment" -> Triple(I.Wallet, C.TileGreen, C.Green)
                    "domain" -> Triple(I.Globe, C.TileBlue, C.Blue)
                    "renewal" -> Triple(I.Bell, C.TileAmber, C.Orange)
                    "invoice" -> Triple(I.Receipt, C.TileBlue, C.Blue)
                    "support" -> Triple(I.Headset, C.TileViolet, Color(0xFF5B3FD0))
                    "security" -> Triple(I.Lock, C.TileRose, Color(0xFFB3261E))
                    else -> Triple(I.Server, C.TileViolet, Color(0xFF5B3FD0))
                }
                val shape = RoundedCornerShape(18.dp)
                Row(Modifier.fillMaxWidth().clip(shape).background(if (unread) Color(0xFFF3F7FF) else Color.White).border(1.dp, Color(0xFFDCE5F8), shape)
                    .clickable { if (unread) scope.launch { Api.call("notif_read", "", JSONObject().put("id", o.i("id")), true); tick++ } }.padding(14.dp),
                    verticalAlignment = Alignment.Top) {
                    Tile(icon, bg, fg)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(o.s("title"), color = C.Ink, fontSize = 14.5.sp, fontWeight = if (unread) FontWeight.ExtraBold else FontWeight.Bold, lineHeight = 20.sp)
                        if (o.s("message").isNotEmpty()) Text(o.s("message"), color = C.Muted, fontSize = 13.sp, lineHeight = 19.sp, modifier = Modifier.padding(top = 3.dp))
                        Text(o.s("date"), color = Color(0xFF8A99B8), fontSize = 11.5.sp, modifier = Modifier.padding(top = 5.dp))
                    }
                    if (unread) Box(Modifier.padding(start = 8.dp, top = 6.dp).size(9.dp).clip(CircleShape).background(C.Amber))
                }
            }
        }
    }
}
