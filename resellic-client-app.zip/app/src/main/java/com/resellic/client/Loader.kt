package com.resellic.client

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.ui.res.painterResource
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlin.math.cos
import kotlin.math.sin

/* সাইটের লোডিং চাকার হুবহু অ্যাপ-সংস্করণ: সোনালি আভা + ঘুরন্ত রশ্মি + মাঝে শ্বাস নেওয়া আইকন */
private val rayAngles = floatArrayOf(-1.4f, 10.4f, 24.2f, 41.0f, 54.8f, 67.0f, 83.7f, 93.3f, 107.9f, 127.1f, 139.6f, 148.8f, 167.6f, 180.7f, 196.2f, 208.3f, 223.4f, 232.3f, 246.4f, 264.4f, 279.9f, 291.5f, 307.3f, 319.8f, 333.5f, 344.4f)
private val rayTips = floatArrayOf(18.0f, 10.3f, 10.9f, 19.6f, 4.5f, 8.5f, 13.1f, 3.8f, 18.6f, 17.4f, 13.6f, 19.8f, 12.4f, 11.9f, 7.0f, 10.5f, 15.2f, 12.6f, 11.2f, 5.7f, 14.7f, 9.4f, 2.1f, 19.8f, 1.1f, 13.3f)

@Composable
fun SiteLoader(size: androidx.compose.ui.unit.Dp = 130.dp) {
    val t = rememberInfiniteTransition(label = "loader")
    val spin by t.animateFloat(0f, 360f, infiniteRepeatable(tween(3000, easing = LinearEasing)), label = "spin")
    val flick by t.animateFloat(1f, 0.75f, infiniteRepeatable(tween(1200, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "flick")
    val breathe by t.animateFloat(0.94f, 1.04f, infiniteRepeatable(tween(1600, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "breathe")
    Box(Modifier.size(size), Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val k = this.size.minDimension / 130f
            val c = Offset(this.size.width / 2, this.size.height / 2)
            // সোনালি আভা
            drawCircle(Brush.radialGradient(0f to Color(0xFFFFF4D6), 0.27f to Color(0xFFFFF4D6), 0.33f to Color(0xD9FFD678), 0.6f to Color(0x00FFB020), center = c, radius = 65f * k), radius = 65f * k, center = c)
            // ঘুরন্ত রশ্মি
            rotate(spin, c) {
                for (n in rayAngles.indices) {
                    val a = Math.toRadians(rayAngles[n].toDouble() - 90.0)
                    val base = 34f * k; val tip = (65f - rayTips[n]) * k; val hw = 1.2f * k
                    val ux = cos(a).toFloat(); val uy = sin(a).toFloat(); val px = -uy; val py = ux
                    val p = Path().apply {
                        moveTo(c.x + ux * base + px * hw, c.y + uy * base + py * hw)
                        lineTo(c.x + ux * tip, c.y + uy * tip)
                        lineTo(c.x + ux * base - px * hw, c.y + uy * base - py * hw)
                        close()
                    }
                    drawPath(p, Color(0xFFFFB020).copy(alpha = flick))
                }
            }
        }
        // মাঝের আইকন
        Image(painterResource(R.drawable.site_icon), null, Modifier.size(size * 0.46f).scale(breathe))
    }
}

/** পুরো পাতা জুড়ে লোডিং (পাতা ডেটা আনার সময়) */
@Composable
fun PageLoading() { Box(Modifier.fillMaxWidth().padding(vertical = 40.dp), Alignment.Center) { SiteLoader(110.dp) } }

/** অ্যাপ খোলার ইন্ট্রো: নীল পর্দা, লোগো ভেসে ওঠে, নিচে লোডিং চাকা */
@Composable
fun Splash(onDone: () -> Unit) {
    var show by remember { mutableStateOf(false) }
    val a by animateFloatAsState(if (show) 1f else 0f, tween(700), label = "a")
    val s by animateFloatAsState(if (show) 1f else 0.85f, tween(700, easing = FastOutSlowInEasing), label = "s")
    LaunchedEffect(Unit) {
        show = true
        // টোকেন এখনো ঠিক আছে কি না দেখে নেওয়া (বাতিল হলে নিজে থেকে লগআউট)
        if (Session.loggedIn) Api.call("me", "", null, true)
        delay(1800)
        onDone()
    }
    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(C.Blue, C.BlueDark))), Alignment.Center) {
        Column(Modifier.scale(s), horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.size(92.dp).clip(RoundedCornerShape(28.dp)).background(Color.White.copy(alpha = 0.14f * a)), Alignment.Center) {
                Image(painterResource(R.drawable.site_icon_white), null, Modifier.size(64.dp))
            }
            Text("Resellic", color = Color.White, fontSize = 38.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.padding(top = 18.dp))
            Text("Domains, hosting and more", color = Color.White.copy(alpha = 0.8f), fontSize = 14.sp)
        }
        Box(Modifier.align(Alignment.BottomCenter).padding(bottom = 64.dp).navigationBarsPadding()) { SplashRing(80.dp) }
    }
}

/** স্প্ল্যাশের লোডার: সাদা আইকনের চারপাশে ঘুরন্ত সোনালি চাপ */
@Composable
fun SplashRing(size: androidx.compose.ui.unit.Dp = 80.dp) {
    val t = rememberInfiniteTransition(label = "ring")
    val spin by t.animateFloat(0f, 360f, infiniteRepeatable(tween(1100, easing = LinearEasing)), label = "spin")
    Box(Modifier.size(size), Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val w = this.size.minDimension * 0.07f
            val inset = w / 2
            val arcSize = androidx.compose.ui.geometry.Size(this.size.width - w, this.size.height - w)
            val tl = Offset(inset, inset)
            drawCircle(Color(0x2EFFFFFF), radius = this.size.minDimension / 2 - inset, style = androidx.compose.ui.graphics.drawscope.Stroke(w))
            drawArc(Color(0xFFFFB020), spin, 120f, false, tl, arcSize, style = androidx.compose.ui.graphics.drawscope.Stroke(w, cap = androidx.compose.ui.graphics.StrokeCap.Round))
        }
        Image(painterResource(R.drawable.site_icon_white), null, Modifier.size(size * 0.46f))
    }
}
