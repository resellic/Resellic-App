package com.resellic.client

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

/** সাইটের রঙ */
object C {
    val Blue = Color(0xFF1D4ED8)
    val BlueDark = Color(0xFF1E40AF)
    val Ink = Color(0xFF0F1B2D)
    val Muted = Color(0xFF65758B)
    val Line = Color(0xFFD6E0F7)
    val Canvas = Color(0xFFEEF3FF)
    val Field = Color(0xFFF6F8FE)
    val Amber = Color(0xFFFFB020)
    val Mint = Color(0xFF0FA36B)
    val Red = Color(0xFFD93025)
    // হালকা টাইল
    val TileBlue = Color(0xFFE6EDFF); val TileGreen = Color(0xFFE6F4EA)
    val TileAmber = Color(0xFFFFF0D9); val TileRose = Color(0xFFFBE7E2); val TileViolet = Color(0xFFEEE9FB)
    val Green = Color(0xFF1E7A3C); val Orange = Color(0xFFB26A00); val Coral = Color(0xFFD2471F)
}

@Composable
fun ResellicTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = lightColorScheme(primary = C.Blue, onPrimary = Color.White, background = Color.White, surface = Color.White,
            onSurface = C.Ink, secondary = C.Amber, outline = C.Line),
        typography = Typography(),
        content = content
    )
}
