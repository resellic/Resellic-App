package com.resellic.client

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.clickable
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.json.JSONObject

private fun chatBody(a: String, vararg kv: Pair<String, Any>): JSONObject {
    val j = JSONObject().put("a", a).put("vid", Session.chatVid()).put("url", "app://resellic").put("title", "Resellic App").put("device", "mobile")
    kv.forEach { j.put(it.first, it.second) }
    return j
}

/** লাইভ চ্যাট — সাইটের chat.php-র সাথেই কথা বলে (অ্যাডমিন অ্যাপে একই কথোপকথন দেখা যায়) */
@Composable
fun ChatScreen() {
    val scope = rememberCoroutineScope()
    val u = Session.user
    var started by remember { mutableStateOf<Boolean?>(null) }
    var online by remember { mutableStateOf(false) }
    val msgs = remember { mutableStateListOf<JSONObject>() }
    var lastId by remember { mutableIntStateOf(0) }
    var text by remember { mutableStateOf("") }
    var err by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    var name by remember { mutableStateOf(((u?.s("first_name") ?: "") + " " + (u?.s("last_name") ?: "")).trim()) }
    var phone by remember { mutableStateOf(u?.s("phone") ?: "") }
    var email by remember { mutableStateOf(u?.s("email") ?: "") }
    val list = rememberLazyListState()

    suspend fun poll() {
        val j = Api.chat(chatBody("poll", "since" to lastId))
        if (!j.optBoolean("ok")) return
        online = j.optBoolean("online"); started = j.optBoolean("started")
        val a = j.optJSONArray("messages") ?: return
        for (n in 0 until a.length()) { val m = a.getJSONObject(n); if (m.i("id") > lastId) { msgs.add(m); lastId = m.i("id") } }
    }

    androidx.compose.runtime.DisposableEffect(Unit) { Notifier.chatOpen = true; onDispose { Notifier.chatOpen = false } }
    LaunchedEffect(Unit) { while (true) { poll(); delay(4000) } }
    LaunchedEffect(started) {
        if (started == false && Session.loggedIn && name.isNotBlank()) {
            val j = Api.chat(chatBody("start", "member" to true, "name" to name.trim(), "phone" to phone.trim(), "email" to email.trim()))
            if (j.optBoolean("ok")) { started = true; poll() } else err = j.s("error", "Could not start the chat")
        }
    }
    LaunchedEffect(msgs.size) { if (msgs.isNotEmpty()) list.animateScrollToItem(msgs.size - 1) }

    Column(Modifier.fillMaxSize().background(Color(0xFFF4F7FF)).imePadding()) {
        // অবস্থা বার
        Row(Modifier.fillMaxWidth().background(Color.White).padding(horizontal = 16.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(9.dp).clip(CircleShape).background(if (online) C.Mint else Color(0xFFB0B8C8)))
            Spacer(Modifier.width(8.dp))
            Column {
                Text("Support Team", color = C.Ink, fontWeight = FontWeight.ExtraBold, fontSize = 14.sp)
                Text(if (online) "Online — we usually reply in minutes" else "Offline — leave a message, we will reply by email", color = C.Muted, fontSize = 11.5.sp)
            }
        }
        if (started == null) Box(Modifier.weight(1f).fillMaxWidth(), Alignment.Center) { SiteLoader(100.dp) }
        else if (started == false && Session.loggedIn && err == null) Box(Modifier.weight(1f).fillMaxWidth(), Alignment.Center) { SiteLoader(100.dp) }
        else if (started == false) {
            // শুরুর ফর্ম: নাম, মোবাইল, ইমেইল (সাইটের মতোই)
            Column(Modifier.weight(1f).fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Start a chat", color = C.Ink, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
                Text("Tell us who you are and we will connect you with our team.", color = C.Muted, fontSize = 13.sp)
                Field("Name", name, { name = it }, I.Person)
                Field("Mobile number", phone, { phone = it }, I.Headset, keyboard = KeyboardType.Phone, placeholder = "01XXXXXXXXX")
                Field("Email", email, { email = it }, I.Mail, keyboard = KeyboardType.Email)
                ErrorText(err)
                Btn(if (busy) "Please wait…" else "Start chat", {
                    busy = true; err = null
                    scope.launch {
                        val j = Api.chat(chatBody("start", "name" to name.trim(), "phone" to phone.trim(), "email" to email.trim()))
                        busy = false
                        if (j.optBoolean("ok")) { started = true; poll() } else err = j.s("error", "Could not start the chat")
                    }
                }, Modifier.fillMaxWidth(), h = 52.dp, enabled = !busy && name.isNotBlank() && phone.isNotBlank() && email.isNotBlank())
            }
        } else {
            LazyColumn(Modifier.weight(1f).fillMaxWidth(), state = list, contentPadding = PaddingValues(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(msgs) { m ->
                    val mine = m.s("sender") == "visitor"
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (mine) Arrangement.End else Arrangement.Start) {
                        Column(Modifier.widthIn(max = 280.dp)
                            .clip(if (mine) RoundedCornerShape(16.dp, 4.dp, 16.dp, 16.dp) else RoundedCornerShape(4.dp, 16.dp, 16.dp, 16.dp))
                            .background(if (mine) C.Blue else Color.White)
                            .then(if (mine) Modifier else Modifier.border(1.dp, C.Line, RoundedCornerShape(4.dp, 16.dp, 16.dp, 16.dp)))
                            .padding(horizontal = 13.dp, vertical = 9.dp)) {
                            Text(m.s("body"), color = if (mine) Color.White else C.Ink, fontSize = 14.5.sp)
                            Text(m.s("created_at").takeLast(8).take(5), color = if (mine) Color(0xB3FFFFFF) else C.Muted, fontSize = 10.5.sp, modifier = Modifier.padding(top = 3.dp))
                        }
                    }
                }
            }
            if (err != null) Text(err!!, color = Color(0xFFB3261E), fontSize = 12.sp, modifier = Modifier.padding(horizontal = 16.dp))
            Row(Modifier.fillMaxWidth().background(Color.White).padding(10.dp).navigationBarsPadding(), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.weight(1f)) {
                    androidx.compose.foundation.text.BasicTextField(text, { text = it }, Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(C.Field)
                        .border(1.5.dp, C.Line, RoundedCornerShape(22.dp)).padding(horizontal = 16.dp, vertical = 12.dp), maxLines = 4,
                        textStyle = androidx.compose.ui.text.TextStyle(color = C.Ink, fontSize = 15.sp),
                        decorationBox = { inner -> if (text.isEmpty()) Text("Type a message…", color = C.Muted, fontSize = 15.sp); inner() })
                }
                Spacer(Modifier.width(8.dp))
                Box(Modifier.size(46.dp).clip(CircleShape).background(if (text.isBlank()) Color(0xFF9DB2EC) else C.Blue).clickable(enabled = text.isNotBlank() && !busy) {
                    val body = text.trim(); text = ""; err = null; busy = true
                    scope.launch {
                        val j = Api.chat(chatBody("send", "body" to body)); busy = false
                        if (j.optBoolean("ok")) poll() else { err = j.s("error", "Could not send"); text = body }
                    }
                }, Alignment.Center) { Icon(I.Send, null, tint = Color.White, modifier = Modifier.size(22.dp)) }
            }
        }
    }
}
