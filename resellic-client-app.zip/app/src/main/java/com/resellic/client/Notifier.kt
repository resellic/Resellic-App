package com.resellic.client

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.google.firebase.messaging.FirebaseMessaging
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/** পেমেন্ট, ইনভয়েস, রিনিউ/মেয়াদ, অর্ডার, সাপোর্ট — সাইটের নোটিফিকেশন ফোনের নোটিশে */
object Notifier {
    private const val CH = "resellic_main"
    @Volatile var chatOpen = false
    private fun prefs(c: Context) = c.getSharedPreferences("notif", Context.MODE_PRIVATE)

    fun channel(c: Context) {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = c.getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel(CH, "Account notifications", NotificationManager.IMPORTANCE_HIGH)
                .apply { description = "Payments, invoices, renewals and important messages" })
        }
    }

    fun canShow(c: Context) = Build.VERSION.SDK_INT < 33 || ContextCompat.checkSelfPermission(c, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

    private fun show(c: Context, id: Int, title: String, text: String) {
        if (!canShow(c)) return
        val open = PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val n = NotificationCompat.Builder(c, CH).setSmallIcon(R.drawable.ic_stat).setContentTitle(title).setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text)).setAutoCancel(true).setContentIntent(open)
            .setColor(0xFF1D4ED8.toInt()).setPriority(NotificationCompat.PRIORITY_HIGH).build()
        try { NotificationManagerCompat.from(c).notify(id, n) } catch (_: SecurityException) {}
    }

    /** সার্ভার থেকে নতুন নোটিফিকেশন এনে ফোনে দেখানো (প্রথমবার পুরোনোগুলো দেখায় না) */
    suspend fun sync(ctx: Context) {
        val c = ctx.applicationContext
        Session.init(c)
        if (!Session.loggedIn) return
        channel(c)
        val p = prefs(c); val key = "last_" + (Session.user?.optInt("id", 0) ?: 0)
        val last = p.getInt(key, -1)
        val j = Api.call("notifications", Api.q("since" to (if (last < 0) 0 else last).toString()), null, true)
        if (!j.optBoolean("ok")) return
        val a = j.optJSONArray("data") ?: return
        var max = last
        val fresh = ArrayList<JSONObject>()
        for (n in 0 until a.length()) {
            val o = a.getJSONObject(n)
            if (o.i("id") > max) max = o.i("id")
            if (!o.optBoolean("read")) fresh.add(o)
        }
        if (last >= 0) for (o in fresh.reversed()) if (!(chatOpen && o.s("category") == "chat")) show(c, o.i("id"), o.s("title"), o.s("message").ifEmpty { o.s("title") })
        if (max != last) p.edit().putInt(key, max).apply()
    }

    /** ১৫ মিনিট পরপর নিজে চেক (Firebase না থাকলেও নোটিশ আসে) */
    fun schedule(c: Context) {
        val req = PeriodicWorkRequestBuilder<PollWorker>(15, TimeUnit.MINUTES)
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()).build()
        WorkManager.getInstance(c.applicationContext).enqueueUniquePeriodicWork("notif_poll", ExistingPeriodicWorkPolicy.KEEP, req)
    }

    /** Firebase টোকেন সার্ভারে জানানো — এরপর নতুন নোটিফিকেশন সঙ্গে সঙ্গে আসে */
    fun registerPush() {
        try { FirebaseMessaging.getInstance().token.addOnSuccessListener { t -> upload(t) } } catch (_: Throwable) {}
    }
    fun upload(t: String) {
        CoroutineScope(Dispatchers.IO).launch { if (Session.loggedIn) Api.call("fcm_token", "", JSONObject().put("token", t), true) }
    }
}

class PollWorker(c: Context, p: WorkerParameters) : CoroutineWorker(c, p) {
    override suspend fun doWork(): Result { Notifier.sync(applicationContext); return Result.success() }
}

class PushService : FirebaseMessagingService() {
    override fun onNewToken(token: String) { Session.init(applicationContext); Notifier.upload(token) }
    override fun onMessageReceived(message: RemoteMessage) {
        runBlocking(Dispatchers.IO) { withTimeoutOrNull(8000) { Notifier.sync(applicationContext) } }
    }
}
