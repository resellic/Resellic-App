package com.resellic.client

import androidx.compose.ui.platform.LocalContext
import android.app.DownloadManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.URL

/* ---------- ছোট সহায়ক ---------- */
fun copyText(ctx: Context, t: String) {
    (ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("text", t))
    Toast.makeText(ctx, "Copied", Toast.LENGTH_SHORT).show()
}

@Composable
fun Chip(text: String, on: Boolean, onClick: () -> Unit) {
    Text(text, color = if (on) Color.White else C.Ink, fontSize = 13.sp, fontWeight = FontWeight.Bold,
        modifier = Modifier.clip(RoundedCornerShape(50)).background(if (on) C.Ink else Color.White).border(1.dp, C.Line, RoundedCornerShape(50))
            .clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 8.dp))
}

@Composable
fun SwitchRow(label: String, sub: String, checked: Boolean, enabled: Boolean = true, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(label, color = C.Ink, fontSize = 14.sp, fontWeight = FontWeight.ExtraBold)
            if (sub.isNotEmpty()) Text(sub, color = C.Muted, fontSize = 12.sp)
        }
        Switch(checked, onChange, enabled = enabled, colors = SwitchDefaults.colors(checkedTrackColor = C.Blue))
    }
}

@Composable
fun Card(content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).border(1.5.dp, C.Line, RoundedCornerShape(20.dp)).background(Color.White).padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp), content = content)
}

@Composable
fun Stepper(value: Int, min: Int, max: Int, onChange: (Int) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(34.dp).clip(CircleShape).background(C.TileBlue).clickable(enabled = value > min) { onChange(value - 1) }, Alignment.Center) { Text("−", color = C.Blue, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold) }
        Text("$value", color = C.Ink, fontSize = 15.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.width(34.dp), textAlign = androidx.compose.ui.text.style.TextAlign.Center)
        Box(Modifier.size(34.dp).clip(CircleShape).background(C.TileBlue).clickable(enabled = value < max) { onChange(value + 1) }, Alignment.Center) { Text("+", color = C.Blue, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold) }
    }
}

@Composable
fun NetImage(url: String, modifier: Modifier) {
    val bmp by produceState<androidx.compose.ui.graphics.ImageBitmap?>(null, url) {
        value = withContext(Dispatchers.IO) { try { val b = URL(url).readBytes(); BitmapFactory.decodeByteArray(b, 0, b.size)?.asImageBitmap() } catch (e: Exception) { null } }
    }
    bmp?.let { Image(it, null, modifier) }
}

@Composable
fun SectionTitle(t: String) { Text(t, color = C.Ink, fontSize = 15.sp, fontWeight = FontWeight.ExtraBold) }

private fun strs(a: JSONArray?): List<String> = if (a == null) emptyList() else (0 until a.length()).map { a.getString(it) }

/* ===================== কার্ট ===================== */
@Composable
fun CartScreen() {
    val nav = LocalNav.current; val scope = rememberCoroutineScope()
    var cart by remember { mutableStateOf<JSONObject?>(null) }
    var err by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    var code by remember { mutableStateOf("") }
    fun doCall(action: String, b: JSONObject?) {
        busy = true; err = null
        scope.launch {
            val r = Api.call(action, "", b, true); busy = false
            if (r.optBoolean("ok")) cart = r else err = r.s("error")
        }
    }
    LaunchedEffect(Unit) { doCall("cart", null) }
    Screen {
        val c = cart
        if (c == null) { if (err != null) { ErrorText(err); Btn("Try again", { doCall("cart", null) }, Modifier.fillMaxWidth()) } else PageLoading(); return@Screen }
        val doms = c.getJSONArray("domains"); val host = c.getJSONArray("hosting")
        if (c.i("count") == 0) {
            Empty("Your cart is empty")
            Btn("Search a domain", { nav.tab("search") }, Modifier.fillMaxWidth(), icon = I.Search)
            Btn("Order hosting", { nav.tab("plans") }, Modifier.fillMaxWidth(), style = BtnStyle.Out)
            return@Screen
        }
        for (n in 0 until doms.length()) {
            val d = doms.getJSONObject(n); val act = d.s("action")
            Card {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Tile(I.Globe, C.TileBlue, C.Blue); Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(d.s("domain"), color = C.Ink, fontSize = 15.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1)
                        Text(when (act) { "transfer" -> "Transfer"; "renew" -> "Renew"; else -> "New registration" } + if (d.optBoolean("for_hosting")) " · with hosting" else "", color = C.Muted, fontSize = 12.sp)
                    }
                    Text(d.s("price_txt"), color = C.Blue, fontSize = 14.sp, fontWeight = FontWeight.ExtraBold)
                }
                if (!d.optBoolean("premium")) Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Years", color = C.Muted, fontSize = 13.sp, modifier = Modifier.weight(1f))
                    Stepper(d.i("years"), 1, 10) { y -> doCall("cart_update", JSONObject().put("domain", d.s("domain")).put("years", y.toString()).put("privacy", if (d.optBoolean("privacy")) "1" else "0")) }
                }
                SwitchRow("WHOIS privacy", c.s("privacy_price_txt"), d.optBoolean("privacy")) { on ->
                    doCall("cart_update", JSONObject().put("domain", d.s("domain")).put("years", d.i("years").toString()).put("privacy", if (on) "1" else "0")) }
                Text("Remove", color = Color(0xFFB3261E), fontSize = 13.sp, fontWeight = FontWeight.ExtraBold,
                    modifier = Modifier.clickable { doCall("cart_remove", JSONObject().put("domain", d.s("domain")).put("kind", "domain")) })
            }
        }
        for (n in 0 until host.length()) {
            val h = host.getJSONObject(n)
            Card {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Tile(I.Server, C.TileGreen, C.Green); Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(h.s("plan_name"), color = C.Ink, fontSize = 15.sp, fontWeight = FontWeight.ExtraBold)
                        Text(h.s("domain") + " · " + (if (h.s("cycle") == "yearly") "yearly" else "monthly"), color = C.Muted, fontSize = 12.sp)
                    }
                    Text(h.s("price_txt"), color = C.Blue, fontSize = 14.sp, fontWeight = FontWeight.ExtraBold)
                }
                Text("Remove", color = Color(0xFFB3261E), fontSize = 13.sp, fontWeight = FontWeight.ExtraBold,
                    modifier = Modifier.clickable { doCall("cart_remove", JSONObject().put("domain", h.s("domain")).put("kind", "hosting")) })
            }
        }
        Card {
            if (c.s("coupon").isNotEmpty()) Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Coupon " + c.s("coupon"), color = C.Green, fontWeight = FontWeight.ExtraBold, fontSize = 14.sp, modifier = Modifier.weight(1f))
                Text("Remove", color = Color(0xFFB3261E), fontSize = 13.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.clickable { doCall("cart_coupon", JSONObject().put("remove", "1")) })
            } else Row(verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Field("Coupon code", code, { code = it }, modifier = Modifier.weight(1f), placeholder = "Enter code")
                Btn("Apply", { doCall("cart_coupon", JSONObject().put("code", code.trim())) }, Modifier.width(92.dp), style = BtnStyle.Out, h = 54.dp, enabled = code.isNotBlank() && !busy)
            }
        }
        Card {
            KV("Subtotal", c.s("subtotal_txt"))
            if (c.d("discount") > 0) KV("Discount", "−" + c.s("discount_txt"))
            if (c.d("tax") > 0) KV(c.s("tax_label"), c.s("tax_txt"))
            Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween) {
                Text("Total", color = C.Ink, fontSize = 17.sp, fontWeight = FontWeight.ExtraBold)
                Text(c.s("total_txt"), color = C.Blue, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
            }
        }
        ErrorText(err)
        Btn(if (busy) "Please wait…" else "Continue to checkout", { nav.push("checkout") }, Modifier.fillMaxWidth(), style = BtnStyle.Amber, h = 54.dp, enabled = !busy)
        Spacer(Modifier.height(24.dp))
    }
}

/* ===================== চেকআউট ===================== */
@Composable
fun CheckoutScreen() {
    val nav = LocalNav.current; val scope = rememberCoroutineScope()
    var cart by remember { mutableStateOf<JSONObject?>(null) }
    var first by remember { mutableStateOf("") }; var last by remember { mutableStateOf("") }; var company by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }; var phone by remember { mutableStateOf("") }; var addr1 by remember { mutableStateOf("") }
    var addr2 by remember { mutableStateOf("") }; var city by remember { mutableStateOf("") }; var state by remember { mutableStateOf("") }
    var post by remember { mutableStateOf("") }; var country by remember { mutableStateOf("BD") }
    var ns1 by remember { mutableStateOf("") }; var ns2 by remember { mutableStateOf("") }
    var terms by remember { mutableStateOf(false) }
    var err by remember { mutableStateOf<String?>(null) }; var busy by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        val i = Api.call("checkout_info", "", null, true)
        i.optJSONObject("contact")?.let { c ->
            first = c.s("first_name"); last = c.s("last_name"); company = c.s("company"); email = c.s("email"); phone = c.s("phone")
            addr1 = c.s("address1"); addr2 = c.s("address2"); city = c.s("city"); state = c.s("state"); post = c.s("postcode"); country = c.s("country").ifEmpty { "BD" }
        }
        val r = Api.call("cart", "", null, true); if (r.optBoolean("ok")) cart = r else err = r.s("error")
    }
    Screen {
        val c = cart
        if (c == null) { ErrorText(err); if (err == null) PageLoading(); return@Screen }
        Card {
            SectionTitle("Your details")
            Text("This is used as the domain owner (registrant) contact.", color = C.Muted, fontSize = 12.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Field("First name", first, { first = it }, modifier = Modifier.weight(1f)); Field("Last name", last, { last = it }, modifier = Modifier.weight(1f))
            }
            Field("Company (optional)", company, { company = it })
            Field("Email", email, { email = it }, keyboard = KeyboardType.Email)
            Field("Phone", phone, { phone = it }, keyboard = KeyboardType.Phone)
            Field("Address", addr1, { addr1 = it }); Field("Address 2 (optional)", addr2, { addr2 = it })
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Field("City", city, { city = it }, modifier = Modifier.weight(1f)); Field("Post code", post, { post = it }, modifier = Modifier.weight(1f))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Field("State (optional)", state, { state = it }, modifier = Modifier.weight(1f)); Field("Country (2 letters)", country, { country = it.take(2).uppercase() }, modifier = Modifier.weight(1f))
            }
        }
        if (c.getJSONArray("domains").length() > 0) Card {
            SectionTitle("Nameservers (optional)")
            Text("Leave empty to use the default nameservers.", color = C.Muted, fontSize = 12.sp)
            Field("Nameserver 1", ns1, { ns1 = it }); Field("Nameserver 2", ns2, { ns2 = it })
        }
        val bd = c.getJSONArray("bd_terms")
        if (bd.length() > 0) Card {
            SwitchRow("I accept the .bd domain terms", strs(bd).joinToString(", "), terms) { terms = it }
        }
        Card {
            KV("Subtotal", c.s("subtotal_txt"))
            if (c.d("discount") > 0) KV("Discount", "−" + c.s("discount_txt"))
            if (c.d("tax") > 0) KV(c.s("tax_label"), c.s("tax_txt"))
            Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween) {
                Text("Total", color = C.Ink, fontSize = 17.sp, fontWeight = FontWeight.ExtraBold)
                Text(c.s("total_txt"), color = C.Blue, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
            }
        }
        ErrorText(err)
        Btn(if (busy) "Please wait…" else "Place order", {
            busy = true; err = null
            scope.launch {
                val b = JSONObject().put("first_name", first).put("last_name", last).put("company", company).put("email", email).put("phone", phone)
                    .put("address1", addr1).put("address2", addr2).put("city", city).put("state", state).put("postcode", post).put("country", country)
                    .put("order_ns1", ns1).put("order_ns2", ns2).put("bd_terms", if (terms) "1" else "0")
                val r = Api.call("checkout", "", b, true); busy = false
                if (r.optBoolean("ok")) { nav.back(); nav.replace("invoice", r.i("invoice_id").toString()) } else err = r.s("error")
            }
        }, Modifier.fillMaxWidth(), style = BtnStyle.Amber, h = 54.dp, enabled = !busy)
        Spacer(Modifier.height(24.dp))
    }
}

/* ===================== হোস্টিং অর্ডার ===================== */
@Composable
fun HostingOrderScreen(arg: String) {
    val nav = LocalNav.current; val scope = rememberCoroutineScope()
    var tick by remember { mutableIntStateOf(0) }
    val res = load("hplans", "hosting_plans", "", true, tick)
    var planId by remember { mutableIntStateOf(arg.toIntOrNull() ?: 0) }
    var cycle by remember { mutableStateOf("monthly") }
    var mode by remember { mutableStateOf("register") }
    var domain by remember { mutableStateOf("") }; var epp by remember { mutableStateOf("") }
    var check by remember { mutableStateOf<String?>(null) }; var checkOk by remember { mutableStateOf(false) }
    var err by remember { mutableStateOf<String?>(null) }; var busy by remember { mutableStateOf(false) }
    Screen {
        Loaded(res, { tick++ }) { j ->
            val plans = j.getJSONArray("plans")
            if (plans.length() == 0) { Empty("No hosting plans are open for order right now"); return@Loaded }
            var plan = plans.getJSONObject(0)
            for (n in 0 until plans.length()) if (plans.getJSONObject(n).i("id") == planId) plan = plans.getJSONObject(n)
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                for (n in 0 until plans.length()) { val p = plans.getJSONObject(n); Chip(p.s("name"), p.i("id") == plan.i("id")) { planId = p.i("id") } }
            }
            Card {
                Text(plan.s("name"), color = C.Ink, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
                if (plan.s("description").isNotEmpty()) Text(plan.s("description"), color = C.Muted, fontSize = 13.sp)
                for (f in strs(plan.getJSONArray("features"))) Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(I.Check, null, tint = C.Mint, modifier = Modifier.size(16.dp)); Spacer(Modifier.width(8.dp)); Text(f, color = C.Ink, fontSize = 13.sp) }
            }
            Card {
                SectionTitle("Billing")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Chip("Monthly · " + plan.s("monthly_txt"), cycle == "monthly") { cycle = "monthly" }
                    Chip("Yearly · " + plan.s("yearly_txt"), cycle == "yearly") { cycle = "yearly" }
                }
            }
            Card {
                SectionTitle("Domain")
                Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Chip("New domain", mode == "register") { mode = "register"; check = null }
                    Chip("Transfer", mode == "transfer") { mode = "transfer"; check = null }
                    Chip("I have a domain", mode == "own") { mode = "own"; check = null }
                }
                Field("Domain name", domain, { domain = it; check = null }, I.Globe, placeholder = "example.com", keyboard = KeyboardType.Uri)
                if (mode == "transfer") Field("EPP / Auth code", epp, { epp = it }, I.Lock, placeholder = "Code from your current registrar")
                if (mode == "own") {
                    val mine = strs(j.getJSONArray("my_domains"))
                    if (mine.isNotEmpty()) {
                        Text("Your domains", color = C.Muted, fontSize = 12.sp)
                        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) { for (m in mine) Chip(m, domain == m) { domain = m } }
                    }
                }
                if (mode == "register") {
                    Btn("Check availability", {
                        busy = true; err = null; check = null
                        scope.launch {
                            val r = Api.call("hosting_check", Api.q("domain" to domain.trim()), null, true); busy = false
                            if (r.optBoolean("ok")) { checkOk = r.optBoolean("available"); check = if (checkOk) r.s("domain") + " is available · " + r.s("price_txt") else r.s("domain") + " is not available" + (if (r.s("message").isNotEmpty()) ": " + r.s("message") else "") } else err = r.s("error")
                        }
                    }, Modifier.fillMaxWidth(), style = BtnStyle.Out, h = 46.dp, enabled = domain.isNotBlank() && !busy)
                    if (check != null) Text(check!!, color = if (checkOk) C.Green else Color(0xFFB3261E), fontSize = 13.sp, fontWeight = FontWeight.Bold)
                }
            }
            ErrorText(err)
            Btn(if (busy) "Please wait…" else "Add to cart", {
                busy = true; err = null
                scope.launch {
                    val b = JSONObject().put("plan", plan.i("id").toString()).put("mode", mode).put("cycle", cycle).put("domain", domain.trim()).put("epp", epp.trim())
                    val r = Api.call("hosting_add", "", b, true); busy = false
                    if (r.optBoolean("ok")) { nav.back(); nav.push("cart") } else err = r.s("error")
                }
            }, Modifier.fillMaxWidth(), style = BtnStyle.Amber, h = 54.dp, enabled = !busy && domain.isNotBlank())
            Spacer(Modifier.height(24.dp))
        }
    }
}

/* ===================== ডোমেইন ট্রান্সফার ===================== */
@Composable
fun TransferScreen() {
    val nav = LocalNav.current; val scope = rememberCoroutineScope()
    var domain by remember { mutableStateOf("") }; var epp by remember { mutableStateOf("") }
    var err by remember { mutableStateOf<String?>(null) }; var busy by remember { mutableStateOf(false) }
    Screen {
        Card {
            SectionTitle("Transfer a domain to Resellic")
            Text("Unlock the domain at your current registrar and get the EPP / Auth code first. A successful transfer adds 1 year to your term.", color = C.Muted, fontSize = 13.sp)
            Field("Domain name", domain, { domain = it }, I.Globe, placeholder = "example.com", keyboard = KeyboardType.Uri)
            Field("EPP / Auth code", epp, { epp = it }, I.Lock, placeholder = "Code from your current registrar")
        }
        ErrorText(err)
        Btn(if (busy) "Please wait…" else "Add transfer to cart", {
            busy = true; err = null
            scope.launch {
                val r = Api.call("transfer_add", "", JSONObject().put("domain", domain.trim()).put("epp", epp.trim()), true); busy = false
                if (r.optBoolean("ok")) { nav.back(); nav.push("cart") } else err = r.s("error")
            }
        }, Modifier.fillMaxWidth(), style = BtnStyle.Amber, h = 54.dp, enabled = !busy && domain.isNotBlank() && epp.isNotBlank())
    }
}

/* ===================== ডিজিটাল স্টোর ===================== */
@Composable
fun StoreScreen() {
    val nav = LocalNav.current
    var tick by remember { mutableIntStateOf(0) }
    var type by remember { mutableStateOf("") }
    val res = load(type, "store", Api.q("type" to type), false, tick)
    Screen {
        Loaded(res, { tick++ }) { j ->
            val types = j.getJSONArray("types")
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Chip("All", type == "") { type = "" }
                for (n in 0 until types.length()) { val t = types.getJSONObject(n); Chip(t.s("label"), type == t.s("key")) { type = t.s("key") } }
            }
            val a = j.getJSONArray("data")
            if (a.length() == 0) Empty("No products here yet")
            for (n in 0 until a.length()) {
                val p = a.getJSONObject(n)
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).border(1.5.dp, C.Line, RoundedCornerShape(20.dp)).background(Color.White)
                    .clickable { nav.push("product", p.i("id").toString()) }.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(52.dp).clip(RoundedCornerShape(15.dp)).background(C.TileViolet), Alignment.Center) { Text(p.s("emoji"), fontSize = 24.sp) }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(p.s("name"), color = C.Ink, fontSize = 15.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1)
                        Text(p.s("short").ifEmpty { p.s("type_label") }, color = C.Muted, fontSize = 12.sp, maxLines = 2)
                    }
                    Spacer(Modifier.width(8.dp))
                    Column(horizontalAlignment = Alignment.End) {
                        Text(p.s("price_txt"), color = C.Blue, fontSize = 15.sp, fontWeight = FontWeight.ExtraBold)
                        if (p.s("cycle").isNotEmpty()) Text(p.s("cycle"), color = C.Muted, fontSize = 11.sp)
                    }
                }
            }
            Spacer(Modifier.height(70.dp))
        }
    }
}

@Composable
fun ProductScreen(id: String) {
    val nav = LocalNav.current; val scope = rememberCoroutineScope()
    val res = load(id, "store_product", Api.q("id" to id), Session.loggedIn)
    var err by remember { mutableStateOf<String?>(null) }; var busy by remember { mutableStateOf(false) }
    Screen {
        Loaded(res) { j ->
            val p = j.getJSONObject("product")
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(C.Blue).padding(18.dp)) {
                Text(p.s("emoji") + "  " + p.s("type_label").uppercase(), color = Color(0xD9FFFFFF), fontSize = 12.sp, fontWeight = FontWeight.ExtraBold)
                Text(p.s("name"), color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
                if (p.s("short").isNotEmpty()) Text(p.s("short"), color = Color(0xD9FFFFFF), fontSize = 13.sp)
                Spacer(Modifier.height(10.dp))
                Row(verticalAlignment = Alignment.Bottom) {
                    Text(p.s("price_txt"), color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
                    Text("  " + p.s("cycle"), color = Color(0xD9FFFFFF), fontSize = 13.sp)
                    if (p.s("old_txt").isNotEmpty()) Text("  " + p.s("old_txt"), color = Color(0xB3FFFFFF), fontSize = 13.sp, textDecoration = androidx.compose.ui.text.style.TextDecoration.LineThrough)
                }
            }
            val feats = strs(p.getJSONArray("features"))
            if (feats.isNotEmpty()) Card { for (f in feats) Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(I.Check, null, tint = C.Mint, modifier = Modifier.size(16.dp)); Spacer(Modifier.width(8.dp)); Text(f, color = C.Ink, fontSize = 13.5.sp) } }
            if (p.s("description").isNotBlank()) Card { Text(p.s("description"), color = C.Ink, fontSize = 13.5.sp, lineHeight = 20.sp) }
            ErrorText(err)
            if (p.optBoolean("owned")) Btn("You own this — open My Products", { nav.push("products") }, Modifier.fillMaxWidth(), style = BtnStyle.Out, h = 52.dp)
            else Btn(if (busy) "Please wait…" else "Buy now", {
                if (!Session.loggedIn) { nav.replaceAuth("register"); return@Btn }
                busy = true; err = null
                scope.launch {
                    val r = Api.call("store_buy", "", JSONObject().put("id", id), true); busy = false
                    if (!r.optBoolean("ok")) err = r.s("error")
                    else if (r.optBoolean("free")) { nav.back(); nav.push("products") }
                    else { nav.back(); nav.push("invoice", r.i("invoice_id").toString()) }
                }
            }, Modifier.fillMaxWidth(), style = BtnStyle.Amber, h = 54.dp, enabled = !busy)
            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
fun MyProductsScreen() {
    val nav = LocalNav.current; val ctx = LocalContext.current; val scope = rememberCoroutineScope()
    var tick by remember { mutableIntStateOf(0) }
    val res = load("myprod", "products", "", true, tick)
    var err by remember { mutableStateOf<String?>(null) }
    Screen {
        BandCard("My Products", I.Cart, "Store", { nav.push("store") }) {
            Loaded(res, { tick++ }) { j ->
                val a = j.getJSONArray("data")
                if (a.length() == 0) Empty("You have not bought any product yet")
                for (n in 0 until a.length()) {
                    val o = a.getJSONObject(n)
                    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).border(1.5.dp, C.Line, RoundedCornerShape(18.dp)).padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.size(44.dp).clip(RoundedCornerShape(13.dp)).background(C.TileViolet), Alignment.Center) { Text(o.s("emoji"), fontSize = 20.sp) }
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Text(o.s("name"), color = C.Ink, fontSize = 14.5.sp, fontWeight = FontWeight.ExtraBold)
                                Text(o.s("type_label") + " · " + o.s("price_txt") + o.s("cycle"), color = C.Muted, fontSize = 12.sp)
                            }
                            StatusPill(o.s("status"))
                        }
                        if (o.s("status") == "pending" && o.i("invoice_id") > 0) Btn("Pay now", { nav.push("invoice", o.i("invoice_id").toString()) }, Modifier.fillMaxWidth(), h = 42.dp)
                        if (o.s("license_key").isNotEmpty()) Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(C.Field).padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(o.s("license_key"), color = C.Ink, fontSize = 13.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                            Text("Copy", color = C.Blue, fontWeight = FontWeight.ExtraBold, fontSize = 13.sp, modifier = Modifier.clickable { copyText(ctx, o.s("license_key")) })
                        }
                        if (o.s("access").isNotBlank()) Text(o.s("access"), color = C.Ink, fontSize = 13.sp)
                        if (o.s("note").isNotBlank()) Text(o.s("note"), color = C.Ink, fontSize = 13.sp)
                        if (o.optBoolean("waiting")) Text("Our team will deliver this product shortly.", color = C.Orange, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        if (o.optBoolean("has_download")) Btn("Download", {
                            scope.launch {
                                val r = Api.call("product_download", "", JSONObject().put("id", o.i("id").toString()), true)
                                if (!r.optBoolean("ok")) { err = r.s("error"); return@launch }
                                try {
                                    val rq = DownloadManager.Request(Uri.parse(r.s("url"))).setTitle(r.s("name")).setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                                        .setDestinationInExternalFilesDir(ctx, android.os.Environment.DIRECTORY_DOWNLOADS, r.s("name").replace('/', '_'))
                                    if (r.optBoolean("auth")) rq.addRequestHeader("Authorization", "Bearer " + Session.token)
                                    (ctx.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).enqueue(rq)
                                    Toast.makeText(ctx, "Download started", Toast.LENGTH_SHORT).show()
                                } catch (e: Exception) { err = "Could not start the download" }
                            }
                        }, Modifier.fillMaxWidth(), style = BtnStyle.Out, h = 42.dp)
                        if (o.s("status") == "active" && o.s("cycle").isNotEmpty()) SwitchRow("Auto-renew", o.s("expires_at").take(10).let { if (it.isNotEmpty()) "Renews $it" else "" }, o.i("auto_renew") == 1) {
                            scope.launch { Api.call("product_autorenew", "", JSONObject().put("id", o.i("id").toString()), true); tick++ } }
                    }
                }
                ErrorText(err)
            }
        }
        Spacer(Modifier.height(70.dp))
    }
}

/* ===================== ইনভয়েস পেমেন্ট ===================== */
@Composable
fun InvoicePayBlock(id: String, onPaid: () -> Unit) {
    val nav = LocalNav.current; val scope = rememberCoroutineScope()
    val res = load("meth$id", "invoice_methods", Api.q("id" to id), true)
    var err by remember { mutableStateOf<String?>(null) }; var busy by remember { mutableStateOf(false) }
    Loaded(res) { j ->
        if (j.s("pending_trx").isNotEmpty()) Text("Transaction " + j.s("pending_trx") + " is waiting to be confirmed. Once confirmed, this invoice is paid automatically.", color = C.Orange, fontSize = 13.sp, fontWeight = FontWeight.Bold)
        val m = j.getJSONArray("methods")
        if (m.length() == 0) Text("No payment method is available right now. Please contact support.", color = C.Muted, fontSize = 13.sp)
        SectionTitle("Pay with")
        for (n in 0 until m.length()) {
            val x = m.getJSONObject(n)
            RowCard(if (x.s("code") == "pay") I.Receipt else I.Wallet, if (x.s("code") == "pay") C.TileBlue else C.TileGreen, if (x.s("code") == "pay") C.Blue else C.Green, x.s("label"), x.s("sub"),
                right = { if (x.optBoolean("enabled")) ArrowDot() else Pill("Low balance", C.TileAmber, C.Orange) },
                onClick = if (!x.optBoolean("enabled") || busy) null else ({
                    busy = true; err = null
                    scope.launch {
                        val r = Api.call("invoice_pay", "", JSONObject().put("id", id).put("gateway", x.s("code")), true); busy = false
                        if (!r.optBoolean("ok")) err = r.s("error")
                        else if (r.optBoolean("paid")) onPaid()
                        else if (r.s("pay_token").isNotEmpty()) nav.push("paytoken", r.s("pay_url") + "|" + id)
                    }
                }))
        }
        ErrorText(err)
    }
}


/* ===================== রেফারেল ===================== */
@Composable
fun ReferralScreen() {
    val ctx = LocalContext.current; val scope = rememberCoroutineScope()
    var tick by remember { mutableIntStateOf(0) }
    val res = load("ref", "referral", "", true, tick)
    var method by remember { mutableStateOf("bKash") }; var acct by remember { mutableStateOf("") }; var amt by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf<String?>(null) }; var err by remember { mutableStateOf<String?>(null) }; var busy by remember { mutableStateOf(false) }
    Screen {
        Loaded(res, { tick++ }) { j ->
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(26.dp)).background(C.Blue).padding(18.dp)) {
                Text("Referral balance", color = Color(0xD9FFFFFF), fontSize = 12.5.sp, fontWeight = FontWeight.Bold)
                Text(j.s("balance_txt"), color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold)
                Text("You earn " + j.s("bonus_txt") + " for each friend you refer", color = Color(0xD9FFFFFF), fontSize = 12.5.sp)
            }
            Card {
                SectionTitle("Your referral code")
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(C.Field).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(j.s("code"), color = C.Ink, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.weight(1f))
                    Text("Copy", color = C.Blue, fontWeight = FontWeight.ExtraBold, modifier = Modifier.clickable { copyText(ctx, j.s("code")) })
                }
                Btn("Share my link", {
                    val i = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, "Join Resellic: " + j.s("link"))
                    ctx.startActivity(Intent.createChooser(i, "Share").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                }, Modifier.fillMaxWidth(), style = BtnStyle.Out, h = 46.dp, icon = I.Send)
            }
            Card {
                KV("Friends referred", j.i("referred").toString()); KV("Total earned", j.s("earned_txt")); KV("Used", j.s("used_txt"))
                if (j.i("pending_count") > 0) KV("Pending (" + j.i("pending_count") + ")", j.s("pending_txt"))
            }
            Card {
                SectionTitle("Withdraw")
                Text("Minimum " + j.s("min_withdraw_txt"), color = C.Muted, fontSize = 12.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { for (m in listOf("bKash", "Nagad", "Rocket", "Upay")) Chip(m, method == m) { method = m } }
                Field("Mobile number", acct, { acct = it }, keyboard = KeyboardType.Phone, placeholder = "01XXXXXXXXX")
                Field("Amount", amt, { amt = it }, keyboard = KeyboardType.Number)
                if (msg != null) Text(msg!!, color = C.Green, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                ErrorText(err)
                Btn(if (busy) "Please wait…" else "Request withdrawal", {
                    busy = true; err = null; msg = null
                    scope.launch {
                        val r = Api.call("referral_withdraw", "", JSONObject().put("method", method).put("account", acct.trim()).put("amount", amt.trim()), true); busy = false
                        if (r.optBoolean("ok")) { msg = r.s("message"); tick++ } else err = r.s("error")
                    }
                }, Modifier.fillMaxWidth(), h = 48.dp, enabled = !busy && acct.isNotBlank() && amt.isNotBlank())
            }
            val wd = j.getJSONArray("withdrawals")
            if (wd.length() > 0) BandCard("Withdrawals", I.Wallet) { for (k in 0 until wd.length()) { val w = wd.getJSONObject(k)
                RowCard(I.Wallet, C.TileAmber, C.Orange, w.s("amount_txt"), w.s("method") + " · " + w.s("date"), right = { StatusPill(w.s("status")) }) } }
            val lg = j.getJSONArray("log")
            if (lg.length() > 0) BandCard("Earnings", I.Gift) { for (k in 0 until lg.length()) { val l = lg.getJSONObject(k)
                RowCard(I.Gift, if (l.optBoolean("neg")) C.TileRose else C.TileGreen, if (l.optBoolean("neg")) Color(0xFFB3261E) else C.Green,
                    (if (l.optBoolean("neg")) "−" else "+") + l.s("amount_txt"), l.s("trigger").replace('_', ' ') + " · " + l.s("date")) } }
            val us = j.getJSONArray("users")
            if (us.length() > 0) BandCard("Friends", I.Person) { for (k in 0 until us.length()) { val x = us.getJSONObject(k); RowCard(I.Person, C.TileBlue, C.Blue, x.s("name").ifEmpty { "Friend" }, x.s("date")) } }
            Spacer(Modifier.height(70.dp))
        }
    }
}

/* ===================== সার্ভার স্ট্যাটাস ===================== */
@Composable
fun StatusScreen() {
    var tick by remember { mutableIntStateOf(0) }
    val res = load("status", "status", "", false, tick)
    Screen {
        Loaded(res, { tick++ }) { j ->
            val ok = j.optBoolean("all_ok")
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(if (ok) C.Mint else C.Orange).padding(18.dp)) {
                Text(if (ok) "All systems are running normally" else "Some services are having problems", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.ExtraBold)
            }
            if (j.s("notice").isNotEmpty()) Card { Text(j.s("notice"), color = C.Ink, fontSize = 13.5.sp) }
            val a = j.getJSONArray("data")
            for (n in 0 until a.length()) { val x = a.getJSONObject(n)
                RowCard(I.Server, if (x.optBoolean("ok")) C.TileGreen else C.TileRose, if (x.optBoolean("ok")) C.Green else Color(0xFFB3261E), x.s("name"),
                    right = { Pill(if (x.optBoolean("ok")) "Online" else "Offline", if (x.optBoolean("ok")) C.TileGreen else C.TileRose, if (x.optBoolean("ok")) C.Green else Color(0xFFB3261E)) }) }
            Spacer(Modifier.height(70.dp))
        }
    }
}

/* ===================== ডোমেইন ম্যানেজ ===================== */
@Composable
fun DomainManageScreen(id: String) {
    val nav = LocalNav.current; val ctx = LocalContext.current; val scope = rememberCoroutineScope()
    var tick by remember { mutableIntStateOf(0) }
    val res = load(id, "domain_more", Api.q("id" to id), true, tick)
    var msg by remember { mutableStateOf<String?>(null) }; var err by remember { mutableStateOf<String?>(null) }; var busy by remember { mutableStateOf(false) }
    var years by remember { mutableIntStateOf(1) }
    val ns = remember { mutableStateListOf("", "", "", "") }
    var epp by remember { mutableStateOf("") }
    var otpAct by remember { mutableStateOf<String?>(null) }; var otpExtra by remember { mutableStateOf(JSONObject()) }; var otpMsg by remember { mutableStateOf("") }; var otpCode by remember { mutableStateOf("") }
    var dType by remember { mutableStateOf("A") }; var dHost by remember { mutableStateOf("") }; var dVal by remember { mutableStateOf("") }; var dTtl by remember { mutableStateOf("3600") }; var dPri by remember { mutableStateOf("0") }
    var cHost by remember { mutableStateOf("") }; var cIp by remember { mutableStateOf("") }
    LaunchedEffect(res.json) { res.json?.optJSONArray("nameservers")?.let { a -> for (k in 0 until 4) ns[k] = if (k < a.length()) a.getString(k) else "" } }
    fun act(a: String, extra: JSONObject = JSONObject(), code: String = "") {
        busy = true; msg = null; err = null
        scope.launch {
            val b = JSONObject(extra.toString()).put("id", id).put("do", a); if (code.isNotEmpty()) b.put("code", code)
            val r = Api.call("domain_do", "", b, true); busy = false
            when {
                r.optBoolean("otp") -> { otpAct = a; otpExtra = extra; otpMsg = r.s("error"); if (code.isNotEmpty()) otpCode = "" }
                r.optBoolean("ok") -> {
                    otpAct = null; otpCode = ""
                    if (r.s("epp").isNotEmpty()) epp = r.s("epp")
                    if (r.i("invoice_id") > 0) nav.push("invoice", r.i("invoice_id").toString()) else { msg = r.s("message").ifEmpty { "Done" }; if (a != "epp") tick++ }
                }
                else -> { otpAct = null; err = r.s("message").ifEmpty { r.s("error") } }
            }
        }
    }
    if (otpAct != null) AlertDialog(onDismissRequest = { otpAct = null; otpCode = "" },
        title = { Text("Enter the code") },
        text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) { Text(otpMsg, color = C.Muted, fontSize = 13.sp); Field("6-digit code", otpCode, { otpCode = it.filter { c -> c.isDigit() }.take(6) }, keyboard = KeyboardType.Number) } },
        confirmButton = { TextButton(onClick = { act(otpAct!!, otpExtra, otpCode) }, enabled = otpCode.length == 6 && !busy) { Text("Confirm") } },
        dismissButton = { TextButton(onClick = { otpAct = null; otpCode = "" }) { Text("Cancel") } })
    Screen {
        Loaded(res, { tick++ }) { j ->
            val edit = j.optBoolean("editable")
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(C.Blue).padding(18.dp)) {
                Text(j.s("domain"), color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
                Spacer(Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { StatusPill(j.s("status")); Pill(daysLeft(j.s("expires_at")), Color(0x29FFFFFF), Color.White) }
            }
            if (msg != null) Text(msg!!, color = C.Green, fontWeight = FontWeight.Bold, fontSize = 13.5.sp)
            ErrorText(err)
            if (j.optBoolean("renewable")) Card {
                SectionTitle("Renew")
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Years", color = C.Muted, fontSize = 13.sp, modifier = Modifier.weight(1f)); Stepper(years, 1, 9) { years = it }
                }
                Btn(if (busy) "Please wait…" else "Create renewal invoice", { act("renew", JSONObject().put("years", years.toString())) }, Modifier.fillMaxWidth(), style = BtnStyle.Amber, h = 48.dp, enabled = !busy)
            }
            if (edit) {
                Card {
                    SectionTitle("Settings")
                    SwitchRow("Auto-renew", "Renew automatically before it expires", j.i("auto_renew") == 1, !busy) { act("autorenew", JSONObject().put("value", if (it) "1" else "0")) }
                    SwitchRow("Registrar lock", "Stops unwanted transfers", j.i("lock") == 1, !busy) { act("lock", JSONObject().put("value", if (it) "1" else "0")) }
                    SwitchRow("WHOIS privacy", "Hides your contact details", j.i("privacy") == 1, !busy) { act("privacy", JSONObject().put("value", if (it) "1" else "0")) }
                }
                Card {
                    SectionTitle("Nameservers")
                    for (k in 0 until 4) Field("Nameserver ${k + 1}", ns[k], { ns[k] = it }, placeholder = if (k < 2) "Required" else "Optional")
                    Btn(if (busy) "Please wait…" else "Save nameservers", { act("nameservers", JSONObject().put("ns", JSONArray(ns.filter { it.isNotBlank() }.map { it.trim() }))) }, Modifier.fillMaxWidth(), h = 46.dp, enabled = !busy)
                }
                Card {
                    SectionTitle("DNS records")
                    val dns = j.getJSONArray("dns")
                    if (dns.length() == 0) Text("No records yet", color = C.Muted, fontSize = 13.sp)
                    for (k in 0 until dns.length()) { val r = dns.getJSONObject(k)
                        Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                            Pill(r.s("type"), C.TileBlue, C.Blue); Spacer(Modifier.width(8.dp))
                            Column(Modifier.weight(1f)) { Text(r.s("host").ifEmpty { "@" }, color = C.Ink, fontWeight = FontWeight.Bold, fontSize = 13.sp); Text(r.s("value"), color = C.Muted, fontSize = 12.sp) }
                            Text("Delete", color = Color(0xFFB3261E), fontSize = 12.5.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.clickable(enabled = !busy) { act("dns_delete", JSONObject().put("record_id", r.i("id").toString())) })
                        } }
                    Btn("Pull records from registrar", { act("dns_pull") }, Modifier.fillMaxWidth(), style = BtnStyle.Out, h = 42.dp, enabled = !busy)
                    Text("Add a record", color = C.Ink, fontSize = 13.5.sp, fontWeight = FontWeight.ExtraBold)
                    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) { for (t in strs(j.getJSONArray("dns_types"))) Chip(t, dType == t) { dType = t } }
                    Field("Host", dHost, { dHost = it }, placeholder = "@ or www")
                    Field("Value", dVal, { dVal = it }, placeholder = "e.g. 192.0.2.1")
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Field("TTL", dTtl, { dTtl = it }, keyboard = KeyboardType.Number, modifier = Modifier.weight(1f))
                        if (dType == "MX" || dType == "SRV") Field("Priority", dPri, { dPri = it }, keyboard = KeyboardType.Number, modifier = Modifier.weight(1f))
                    }
                    Btn(if (busy) "Please wait…" else "Add record", { act("dns_add", JSONObject().put("type", dType).put("host", dHost.trim()).put("value", dVal.trim()).put("ttl", dTtl).put("priority", dPri)); dVal = "" }, Modifier.fillMaxWidth(), h = 46.dp, enabled = !busy && dVal.isNotBlank())
                }
                Card {
                    SectionTitle("Child nameservers")
                    val cn = j.getJSONArray("custom_ns")
                    for (k in 0 until cn.length()) { val c = cn.getJSONObject(k)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) { Text(c.s("host"), color = C.Ink, fontWeight = FontWeight.Bold, fontSize = 13.sp); Text(c.s("ip") + " · " + c.s("status"), color = C.Muted, fontSize = 12.sp) }
                            Text("Delete", color = Color(0xFFB3261E), fontSize = 12.5.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.clickable(enabled = !busy) { act("ns_child_delete", JSONObject().put("cn_id", c.i("id").toString())) })
                        } }
                    Field("Name", cHost, { cHost = it }, placeholder = "ns1")
                    Field("IP address", cIp, { cIp = it }, placeholder = "192.0.2.1")
                    Btn(if (busy) "Please wait…" else "Add nameserver", { act("ns_child_add", JSONObject().put("ns_host", cHost.trim()).put("ns_ip", cIp.trim())); cHost = ""; cIp = "" }, Modifier.fillMaxWidth(), style = BtnStyle.Out, h = 46.dp, enabled = !busy && cHost.isNotBlank() && cIp.isNotBlank())
                }
                Card {
                    SectionTitle("Transfer-out auth code (EPP)")
                    if (epp.isNotEmpty()) Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(C.Field).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(epp, color = C.Ink, fontWeight = FontWeight.ExtraBold, fontSize = 15.sp, modifier = Modifier.weight(1f))
                        Text("Copy", color = C.Blue, fontWeight = FontWeight.ExtraBold, modifier = Modifier.clickable { copyText(ctx, epp) })
                    }
                    Btn(if (busy) "Please wait…" else "Show auth code", { act("epp") }, Modifier.fillMaxWidth(), style = BtnStyle.Out, h = 46.dp, enabled = !busy)
                }
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}

/* ===================== হোস্টিং ম্যানেজ (ছোট কাজ) ===================== */
@Composable
fun HostingActions(id: String, status: String, onChanged: () -> Unit) {
    val nav = LocalNav.current; val scope = rememberCoroutineScope()
    var msg by remember { mutableStateOf<String?>(null) }; var err by remember { mutableStateOf<String?>(null) }; var busy by remember { mutableStateOf(false) }
    var pw by remember { mutableStateOf("") }
    val unpaid = load("hu$id", "hosting_unpaid", Api.q("id" to id), true)
    fun act(a: String, extra: JSONObject = JSONObject()) {
        busy = true; msg = null; err = null
        scope.launch {
            val r = Api.call("hosting_do", "", extra.put("id", id).put("do", a), true); busy = false
            when {
                !r.optBoolean("ok") -> err = r.s("error")
                r.s("url").isNotEmpty() -> nav.push("web", "url:" + r.s("url"))
                r.i("invoice_id") > 0 -> nav.push("invoice", r.i("invoice_id").toString())
                else -> { msg = r.s("message"); onChanged() }
            }
        }
    }
    unpaid.json?.optJSONObject("invoice")?.let { v ->
        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(C.TileAmber).clickable { nav.push("invoice", v.i("id").toString()) }.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Invoice " + v.s("invoice_no") + " · " + v.s("total_txt") + " is waiting for payment", color = C.Orange, fontWeight = FontWeight.ExtraBold, fontSize = 13.sp, modifier = Modifier.weight(1f))
            Text("Pay", color = C.Blue, fontWeight = FontWeight.ExtraBold)
        }
    }
    if (msg != null) Text(msg!!, color = C.Green, fontWeight = FontWeight.Bold, fontSize = 13.5.sp)
    ErrorText(err)
    if (status == "active") Card {
        SectionTitle("Change cPanel password")
        Field("New password (min 10 characters)", pw, { pw = it }, password = true)
        Btn(if (busy) "Please wait…" else "Change password", { act("password", JSONObject().put("password", pw)); pw = "" }, Modifier.fillMaxWidth(), style = BtnStyle.Out, h = 46.dp, enabled = !busy && pw.length >= 10)
    }
    if (status == "pending") Btn("Cancel this order", { act("cancel") }, Modifier.fillMaxWidth(), style = BtnStyle.Out, h = 46.dp, enabled = !busy)
}
