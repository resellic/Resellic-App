package com.resellic.client

import android.content.Context
import android.os.Build
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.UUID

/** সাইটের ঠিকানা — শুধু এখানে বদলালেই হয় */
const val SITE = "https://resellic.com/"

/** লগইন অবস্থা: টোকেন ফোনেই থাকে; সার্ভার থেকে 401 এলে নিজে থেকে লগআউট */
object Session {
    private lateinit var sp: android.content.SharedPreferences
    var token by mutableStateOf("")
        private set
    var user by mutableStateOf<JSONObject?>(null)
        private set
    val loggedIn get() = token.isNotEmpty()

    fun init(ctx: Context) {
        sp = ctx.getSharedPreferences("session", Context.MODE_PRIVATE)
        token = sp.getString("token", "") ?: ""
        user = sp.getString("user", null)?.let { runCatching { JSONObject(it) }.getOrNull() }
    }
    fun deviceId(): String {
        var id = sp.getString("device_id", null)
        if (id == null) { id = UUID.randomUUID().toString().replace("-", ""); sp.edit().putString("device_id", id).apply() }
        return id
    }
    /** চ্যাটের ভিজিটর আইডি (৩২ হেক্স) — অ্যাপ ইনস্টল থাকা পর্যন্ত একই */
    fun chatVid(): String = deviceId()
    fun deviceName(): String = (Build.MANUFACTURER + " " + Build.MODEL).trim().take(100)
    fun save(t: String, u: JSONObject?) {
        token = t; user = u
        sp.edit().putString("token", t).putString("user", u?.toString()).apply()
    }
    fun updateUser(u: JSONObject?) { user = u; sp.edit().putString("user", u?.toString()).apply() }
    fun clear() { save("", null) }
}

/** সব নেটওয়ার্ক কল: সার্ভারের client-api.php, JSON ফেরত; ব্যর্থ হলে ok=false + error */
object Api {
    private fun fail(msg: String) = JSONObject().put("ok", false).put("error", msg)

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    suspend fun call(action: String, query: String = "", body: JSONObject? = null, auth: Boolean = false): JSONObject =
        raw(SITE + "client-api.php?a=" + action + (if (query.isNotEmpty()) "&$query" else ""), body, auth)

    /** pay-app.php — অ্যাপের পেমেন্টের ধাপ (bKash/Nagad/ব্যাংক) */
    suspend fun pay(action: String, token: String, body: JSONObject? = null): JSONObject = raw(SITE + "pay-app.php?a=" + action + "&t=" + enc(token), body, false)

    /** chat.php (সাইটের লাইভ চ্যাট) — অ্যাপও একই API ব্যবহার করে */
    suspend fun chat(body: JSONObject): JSONObject = raw(SITE + "chat.php", body, false)

    private suspend fun raw(url: String, body: JSONObject?, auth: Boolean): JSONObject = withContext(Dispatchers.IO) {
        try {
            val c = URL(url).openConnection() as HttpURLConnection
            c.connectTimeout = 15000; c.readTimeout = 25000
            c.setRequestProperty("Accept", "application/json")
            if (auth && Session.token.isNotEmpty()) c.setRequestProperty("Authorization", "Bearer " + Session.token)
            if (body != null) {
                c.requestMethod = "POST"; c.doOutput = true
                c.setRequestProperty("Content-Type", "application/json; charset=utf-8")
                c.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            }
            val code = c.responseCode
            val text = (if (code in 200..399) c.inputStream else c.errorStream)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            c.disconnect()
            val j = runCatching { JSONObject(text) }.getOrNull() ?: return@withContext fail("Server error ($code)")
            if (code == 401 && auth) withContext(Dispatchers.Main) { Session.clear() }
            if (!j.has("ok")) j.put("ok", code in 200..299)
            j
        } catch (e: Exception) {
            fail("No internet connection")
        }
    }

    fun q(vararg p: Pair<String, String>) = p.joinToString("&") { it.first + "=" + enc(it.second) }
}
