package com.resellic.client

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONObject

/* ---------- ছোট সহায়ক ---------- */
fun JSONObject.s(k: String, d: String = ""): String = if (isNull(k)) d else optString(k, d)
fun JSONObject.i(k: String): Int = optInt(k, 0)
fun JSONObject.d(k: String): Double = optDouble(k, 0.0)

class Res(val loading: Boolean, val error: String?, val json: JSONObject?)

/** একটা API কল; key বা tick বদলালে আবার লোড হয় */
@Composable
fun load(key: Any?, action: String, query: String = "", auth: Boolean = false, tick: Int = 0): Res {
    val st = produceState(Res(true, null, null), key, action, query, tick) {
        value = Res(true, null, null)
        val j = Api.call(action, query, null, auth)
        value = if (j.optBoolean("ok")) Res(false, null, j) else Res(false, j.s("error", "Something went wrong"), null)
    }
    return st.value
}

@Composable
fun Loaded(r: Res, onRetry: (() -> Unit)? = null, content: @Composable (JSONObject) -> Unit) {
    when {
        r.loading -> PageLoading()
        r.error != null -> Column(Modifier.fillMaxWidth().padding(28.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(r.error, color = C.Muted, fontSize = 14.sp)
            if (onRetry != null) { Spacer(Modifier.height(12.dp)); Btn("Try again", onRetry, Modifier.width(160.dp), style = BtnStyle.Blue) }
        }
        else -> content(r.json!!)
    }
}

/* ---------- বাটন ---------- */
enum class BtnStyle { Blue, Amber, Out, Soft }

@Composable
fun Btn(text: String, onClick: () -> Unit, modifier: Modifier = Modifier, style: BtnStyle = BtnStyle.Blue, h: Dp = 50.dp, enabled: Boolean = true, icon: ImageVector? = null) {
    val (bg, fg) = when (style) {
        BtnStyle.Blue -> C.Blue to Color.White
        BtnStyle.Amber -> C.Amber to Color(0xFF1B1300)
        BtnStyle.Out -> Color.White to C.Blue
        BtnStyle.Soft -> Color(0x29FFFFFF) to Color.White
    }
    val border = if (style == BtnStyle.Out) Modifier.border(1.5.dp, C.Line, RoundedCornerShape(15.dp)) else if (style == BtnStyle.Soft) Modifier.border(1.5.dp, Color(0x66FFFFFF), RoundedCornerShape(15.dp)) else Modifier
    Row(modifier.height(h).clip(RoundedCornerShape(15.dp)).background(if (enabled) bg else bg.copy(alpha = .5f)).then(border)
        .clickable(enabled = enabled, onClick = onClick).padding(horizontal = 14.dp), Arrangement.Center, Alignment.CenterVertically) {
        if (icon != null) { Icon(icon, null, tint = fg, modifier = Modifier.size(18.dp)); Spacer(Modifier.width(8.dp)) }
        Text(text, color = fg, fontWeight = FontWeight.ExtraBold, fontSize = 14.5.sp, maxLines = 1)
    }
}

/* ---------- ক্যাপসুল ---------- */
@Composable
fun Pill(text: String, bg: Color, fg: Color) {
    Text(text, color = fg, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold,
        modifier = Modifier.clip(RoundedCornerShape(99.dp)).background(bg).padding(horizontal = 10.dp, vertical = 3.dp))
}

@Composable
fun StatusPill(status: String) {
    val s = status.lowercase()
    val (bg, fg) = when {
        s in listOf("active", "paid", "open", "answered", "completed", "done") -> C.TileGreen to C.Green
        s in listOf("pending", "unpaid", "customer_reply", "processing", "coming_soon", "in_progress") -> C.TileAmber to C.Orange
        s in listOf("expired", "overdue", "cancelled", "suspended", "failed", "closed", "terminated") -> C.TileRose to Color(0xFFB3261E)
        else -> C.TileBlue to C.Blue
    }
    Pill(status.replace('_', ' ').replaceFirstChar { it.uppercase() }, bg, fg)
}

/* ---------- আইকন টাইল ---------- */
@Composable
fun Tile(icon: ImageVector, bg: Color, fg: Color, size: Dp = 40.dp) {
    Box(Modifier.size(size).clip(RoundedCornerShape(13.dp)).background(bg), Alignment.Center) { Icon(icon, null, tint = fg, modifier = Modifier.size(size * 0.5f)) }
}

/* ---------- উপরের বার (নীল) ---------- */
@Composable
fun TopBar(title: String? = null, onBack: (() -> Unit)? = null, right: @Composable RowScope.() -> Unit = {}) {
    Column(Modifier.fillMaxWidth().background(C.Blue).statusBarsPadding()) {
        Row(Modifier.fillMaxWidth().height(64.dp).padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
            if (onBack != null) { RoundBtn(I.Back, onBack, filled = true); Spacer(Modifier.width(12.dp)) }
            if (title != null) Text(title, color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            else Logo()
            Spacer(Modifier.weight(1f))
            right()
        }
    }
}

@Composable
fun Logo() { androidx.compose.foundation.Image(androidx.compose.ui.res.painterResource(R.drawable.site_logo_white), "Resellic", Modifier.height(34.dp)) }

/** গোল বাটন: filled=true হলে হালকা সাদা ব্যাকগ্রাউন্ড, নয়তো সাদা আউটলাইন */
@Composable
fun RoundBtn(icon: ImageVector, onClick: () -> Unit, filled: Boolean = false, solid: Boolean = false, badge: Int = 0) {
    Box(Modifier.padding(start = 8.dp).size(40.dp)) {
        Box(Modifier.fillMaxSize().clip(CircleShape)
            .then(if (solid) Modifier.background(Color.White) else if (filled) Modifier.background(Color(0x29FFFFFF)) else Modifier.border(2.dp, Color(0xEBFFFFFF), CircleShape))
            .clickable(onClick = onClick), Alignment.Center) {
            Icon(icon, null, tint = if (solid) C.Blue else Color.White, modifier = Modifier.size(20.dp))
        }
        if (badge > 0) Box(Modifier.align(Alignment.TopEnd).offset(x = 4.dp, y = (-4).dp).defaultMinSize(minWidth = 20.dp, minHeight = 20.dp)
            .clip(CircleShape).background(C.Red).border(2.dp, C.Blue, CircleShape).padding(horizontal = 3.dp), Alignment.Center) {
            Text(if (badge > 9) "9+" else badge.toString(), color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold, maxLines = 1) }
    }
}

/* ---------- নিচের বার: উপরের বারের মতো একই নীল, সোজা কোনা ---------- */
data class Tab(val key: String, val label: String, val icon: ImageVector)

@Composable
fun BottomBar(tabs: List<Tab>, current: String?, onPick: (String) -> Unit) {
    Row(Modifier.fillMaxWidth().background(C.Blue).navigationBarsPadding().height(66.dp)) {
        tabs.forEach { t ->
            val on = t.key == current
            Column(Modifier.weight(1f).fillMaxHeight().clickable { onPick(t.key) }, Arrangement.Center, Alignment.CenterHorizontally) {
                Icon(t.icon, null, tint = if (on) C.Amber else Color(0xFFBCCBFA), modifier = Modifier.size(24.dp))
                Spacer(Modifier.height(3.dp))
                Text(t.label, color = if (on) Color.White else Color(0xFFBCCBFA), fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1)
            }
        }
    }
}

/* ---------- সাইটের মতো নীল ব্যান্ড-হেডলাইনের কার্ড ---------- */
@Composable
fun BandCard(title: String, icon: ImageVector, right: String? = null, onRight: (() -> Unit)? = null, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).border(1.5.dp, C.Line, RoundedCornerShape(24.dp)).background(Color.White)) {
        Row(Modifier.fillMaxWidth().background(C.Blue).padding(horizontal = 18.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(40.dp).clip(RoundedCornerShape(13.dp)).background(Color(0x29FFFFFF)), Alignment.Center) { Icon(icon, null, tint = C.Amber, modifier = Modifier.size(22.dp)) }
            Spacer(Modifier.width(12.dp))
            Text(title, color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.weight(1f))
            if (right != null) Text(right, color = if (onRight != null) C.Blue else Color.White, fontSize = 12.5.sp, fontWeight = FontWeight.ExtraBold,
                modifier = Modifier.clip(RoundedCornerShape(99.dp)).background(if (onRight != null) Color.White else Color(0x29FFFFFF))
                    .then(if (onRight != null) Modifier.clickable(onClick = onRight) else Modifier).padding(horizontal = 14.dp, vertical = 8.dp))
        }
        Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp), content = content)
    }
}

/** তালিকার একটা সারি (আইকন, নাম, বিবরণ, ডানে কিছু) */
@Composable
fun RowCard(icon: ImageVector, bg: Color, fg: Color, title: String, sub: String = "", right: @Composable () -> Unit = {}, onClick: (() -> Unit)? = null) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).border(1.5.dp, C.Line, RoundedCornerShape(18.dp)).background(Color.White)
        .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier).padding(horizontal = 12.dp, vertical = 11.dp), verticalAlignment = Alignment.CenterVertically) {
        Tile(icon, bg, fg)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = C.Ink, fontSize = 14.5.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (sub.isNotEmpty()) Text(sub, color = C.Muted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Spacer(Modifier.width(8.dp))
        right()
    }
}

@Composable
fun ArrowDot() { Box(Modifier.size(32.dp).clip(CircleShape).background(C.Blue), Alignment.Center) { Icon(I.Arrow, null, tint = Color.White, modifier = Modifier.size(16.dp)) } }

/* ---------- ফর্মের ঘর ---------- */
@Composable
fun Field(label: String, value: String, onChange: (String) -> Unit, icon: ImageVector? = null, password: Boolean = false, keyboard: KeyboardType = KeyboardType.Text, modifier: Modifier = Modifier, singleLine: Boolean = true, placeholder: String = "") {
    var show by remember { mutableStateOf(false) }
    Column(modifier) {
        Text(label, color = Color(0xFF3A4A66), fontSize = 12.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.padding(bottom = 5.dp))
        TextField(value, onChange, Modifier.fillMaxWidth().border(1.5.dp, C.Line, RoundedCornerShape(15.dp)).clip(RoundedCornerShape(15.dp)),
            singleLine = singleLine, minLines = if (singleLine) 1 else 4,
            placeholder = { Text(placeholder, color = C.Muted, fontSize = 14.sp) },
            leadingIcon = if (icon != null) ({ Icon(icon, null, tint = C.Blue, modifier = Modifier.size(20.dp)) }) else null,
            trailingIcon = if (password) ({ Icon(I.Eye, null, tint = if (show) C.Blue else Color(0xFF8A99B8), modifier = Modifier.size(22.dp).clickable { show = !show }) }) else null,
            visualTransformation = if (password && !show) PasswordVisualTransformation() else VisualTransformation.None,
            keyboardOptions = KeyboardOptions(keyboardType = if (password) KeyboardType.Password else keyboard),
            colors = TextFieldDefaults.colors(focusedContainerColor = C.Field, unfocusedContainerColor = C.Field,
                focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent, cursorColor = C.Blue))
    }
}

@Composable
fun Screen(modifier: Modifier = Modifier, gap: Dp = 12.dp, pad: Dp = 16.dp, content: @Composable ColumnScope.() -> Unit) {
    Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(pad), verticalArrangement = Arrangement.spacedBy(gap), content = content)
}

@Composable
fun ErrorText(msg: String?) { if (!msg.isNullOrEmpty()) Text(msg, color = Color(0xFFB3261E), fontSize = 13.sp, fontWeight = FontWeight.SemiBold) }

@Composable
fun Empty(text: String) { Text(text, color = C.Muted, fontSize = 14.sp, modifier = Modifier.fillMaxWidth().padding(24.dp), textAlign = androidx.compose.ui.text.style.TextAlign.Center) }

@Composable
fun KV(k: String, v: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 9.dp), Arrangement.SpaceBetween) {
        Text(k, color = C.Muted, fontSize = 13.5.sp)
        Text(v, color = C.Ink, fontSize = 13.5.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 12.dp), maxLines = 2, overflow = TextOverflow.Ellipsis)
    }
}
