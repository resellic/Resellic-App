package com.resellic.client

import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.webkit.CookieManager
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView

/** সাইটের পেজ (অর্ডার, কার্ট, পেমেন্ট, DNS, cPanel…) অ্যাপের ভেতরেই — arg: "go:পাথ" (অটো-লগইন) বা "pub:পাথ" (পাবলিক) */
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun WebScreen(arg: String) {
    var url by remember(arg) { mutableStateOf<String?>(null) }
    var failed by remember(arg) { mutableStateOf(false) }
    var progress by remember { mutableIntStateOf(0) }
    var view by remember { mutableStateOf<WebView?>(null) }
    var canBack by remember { mutableStateOf(false) }
    LaunchedEffect(arg) {
        if (arg.startsWith("go:")) {
            val j = Api.call("go", "", org.json.JSONObject().put("path", arg.removePrefix("go:")), true)
            if (j.optBoolean("ok")) url = j.s("url") else failed = true
        } else url = SITE + arg.removePrefix("pub:")
    }
    BackHandler(enabled = canBack) { view?.goBack() }
    Box(Modifier.fillMaxSize().background(Color.White)) {
        url?.let { u ->
            AndroidView(modifier = Modifier.fillMaxSize(), factory = { c ->
                WebView(c).apply {
                    settings.javaScriptEnabled = true
                    settings.domStorageEnabled = true
                    settings.setSupportMultipleWindows(false)
                    CookieManager.getInstance().setAcceptCookie(true)
                    CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)
                    webViewClient = object : WebViewClient() {
                        override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
                            val s = r.url.toString()
                            if (s.startsWith("http://") || s.startsWith("https://")) return false
                            return true
                        }
                        override fun onPageStarted(v: WebView, u: String?, f: Bitmap?) { progress = 10 }
                        override fun onPageFinished(v: WebView, u: String?) { progress = 100; canBack = v.canGoBack() }
                    }
                    webChromeClient = object : android.webkit.WebChromeClient() {
                        override fun onProgressChanged(v: WebView, p: Int) { progress = p }
                    }
                    view = this
                    loadUrl(u)
                }
            })
        }
        if (failed) Text404()
        if (url == null && !failed || progress in 1..99)
            LinearProgressIndicator(progress = { if (url == null) 0.1f else progress / 100f }, modifier = Modifier.fillMaxWidth().align(Alignment.TopCenter), color = C.Blue, trackColor = Color.Transparent)
    }
    DisposableEffect(Unit) { onDispose { view?.destroy() } }
}

@Composable
private fun BoxScope.Text404() {
    androidx.compose.material3.Text("Could not open this page. Please try again.", color = C.Ink, modifier = Modifier.align(Alignment.Center).padding(24.dp))
}
