package com.resellic.client

import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.webkit.CookieManager
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView

/** শুধু cPanel — হোস্টিং প্যানেল নিজেই ওয়েব, তাই অ্যাপের ভেতরেই খোলে। arg: "url:লিংক" */
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun WebScreen(arg: String) {
    var url by remember(arg) { mutableStateOf<String?>(null) }
    var failed by remember(arg) { mutableStateOf(false) }
    var progress by remember { mutableIntStateOf(0) }
    var view by remember { mutableStateOf<WebView?>(null) }
    var canBack by remember { mutableStateOf(false) }
    LaunchedEffect(arg) { url = arg.removePrefix("url:") }
    BackHandler(enabled = canBack) { view?.goBack() }
    Box(Modifier.fillMaxSize().background(Color.White)) {
        url?.let { u ->
            AndroidView(modifier = Modifier.fillMaxSize(), factory = { c ->
                WebView(c).apply {
                    settings.javaScriptEnabled = true
                    settings.domStorageEnabled = true
                    settings.setSupportMultipleWindows(false)
                    CookieManager.getInstance().setAcceptCookie(true)
                    CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)
                    webViewClient = object : WebViewClient() {
                        override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
                            val s = r.url.toString()
                            if (s.startsWith("http://") || s.startsWith("https://")) return false
                            return true
                        }
                        override fun onPageStarted(v: WebView, u: String?, f: Bitmap?) { progress = 10 }
                        override fun onPageFinished(v: WebView, u: String?) { progress = 100; canBack = v.canGoBack() }
                    }
                    webChromeClient = object : android.webkit.WebChromeClient() {
                        override fun onProgressChanged(v: WebView, p: Int) { progress = p }
                    }
                    view = this
                    loadUrl(u)
                }
            })
        }
        if (failed) Text404()
        if (url == null && !failed || progress in 1..99)
            LinearProgressIndicator(progress = { if (url == null) 0.1f else progress / 100f }, modifier = Modifier.fillMaxWidth().align(Alignment.TopCenter), color = C.Blue, trackColor = Color.Transparent)
    }
    DisposableEffect(Unit) { onDispose { view?.destroy() } }
}

@Composable
private fun BoxScope.Text404() {
    androidx.compose.material3.Text("Could not open this page. Please try again.", color = C.Ink, modifier = Modifier.align(Alignment.Center).padding(24.dp))
}

/** সাইটের নিজস্ব পেমেন্ট পেজের বডি (হেডার/ফুটার/নিচের বার ছাড়া) — arg: "পেজ-লিংক|ইনভয়েস-আইডি" */
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun PayWebScreen(arg: String) {
    val nav = LocalNav.current
    val url = arg.substringBefore("|"); val invId = arg.substringAfter("|", "")
    var progress by remember { mutableIntStateOf(0) }
    var view by remember { mutableStateOf<WebView?>(null) }
    LaunchedEffect(invId) {
        while (invId.isNotEmpty()) {
            kotlinx.coroutines.delay(4000)
            val s = Api.call("invoice_sync", Api.q("id" to invId), null, true)
            if (s.s("status") == "paid") { kotlinx.coroutines.delay(2500); nav.back(); nav.replace("invoice", invId); break }
        }
    }
    val hide = "(function(){var s=document.createElement('style');s.textContent='.pay-header,.hnav,.bnav,.pay-foot-bar,footer{display:none!important}body,html,.pay-body,body.pay-embed,body.pay-page{background:#fff!important;background-image:none!important}.pay-tabs{background:#F1F5FF!important;border:1.5px solid #D6E0F7!important;box-shadow:none!important}.pay-method{border:1.5px solid #D6E0F7!important;box-shadow:0 6px 16px rgba(30,64,175,.10)!important}.pay-success{margin:0 14px!important;border-radius:24px!important;box-shadow:0 8px 22px rgba(30,64,175,.12)!important}.gw-overlay{position:static!important;background:none!important;padding:0!important;display:block!important;overflow:visible!important}.gw-modal{position:static!important;background:#fff!important;border:1.5px solid #C9D6F5!important;box-shadow:0 8px 22px rgba(30,64,175,.12)!important;border-radius:18px!important;max-width:none!important;width:auto!important;margin:0 14px 14px!important;overflow:hidden!important;animation:none!important}.gw-head{background:none!important;color:#0F1B2D!important;padding:14px 16px 4px!important}.gw-head .pd-icon{background:var(--gc)!important;color:#fff!important}.gw-x,.gw-amt{display:none!important}.gw-body{padding:8px 16px 16px!important}.gw-body .pd-row,.gw-body .pd-waiting,.gw-body .pd-submit-manual{background:#F6F8FE!important;border:1px solid #E1E9FB;border-radius:14px!important}';document.head.appendChild(s)})()"
    Box(Modifier.fillMaxSize().background(Color(0xFFEEF3FF))) {
        AndroidView(modifier = Modifier.fillMaxSize(), factory = { c ->
            WebView(c).apply {
                settings.javaScriptEnabled = true
                settings.domStorageEnabled = true
                CookieManager.getInstance().setAcceptCookie(true)
                webViewClient = object : WebViewClient() {
                    override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
                        val s = r.url.toString()
                        // পেমেন্ট পেজের বাইরে (যেমন ৫ সেকেন্ড পরের রিডাইরেক্ট) গেলে সাইটে না গিয়ে অ্যাপের ইনভয়েসে ফেরা
                        if (r.url.path != android.net.Uri.parse(url).path) { if (invId.isNotEmpty()) { nav.back(); nav.replace("invoice", invId) } else nav.back(); return true }
                        return !(s.startsWith("http://") || s.startsWith("https://"))
                    }
                    override fun onPageStarted(v: WebView, u: String?, f: Bitmap?) { progress = 10 }
                    override fun onPageFinished(v: WebView, u: String?) { progress = 100; v.evaluateJavascript(hide, null) }
                }
                webChromeClient = object : android.webkit.WebChromeClient() { override fun onProgressChanged(v: WebView, p: Int) { progress = p } }
                view = this
                loadUrl(url)
            }
        })
        if (progress in 1..99) LinearProgressIndicator(progress = { progress / 100f }, modifier = Modifier.fillMaxWidth().align(Alignment.TopCenter), color = C.Blue, trackColor = Color.Transparent)
    }
    DisposableEffect(Unit) { onDispose { view?.destroy() } }
}
