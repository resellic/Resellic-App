# Resellic Client App (Android, native)

নেটিভ Kotlin + Jetpack Compose অ্যাপ — WebView নয়। সব ডেটা সাইটের সার্ভার থেকে আসে:

- `client-api.php` — সাইটে রুট ফোল্ডারে বসবে (আলাদা ফাইল)
- `chat.php` — লাইভ চ্যাট (সাইটের একই API; অ্যাডমিন অ্যাপে একই কথোপকথন দেখা যায়)

## বিল্ড
Android Studio-তে এই ফোল্ডার খুলুন (বা `gradle :app:assembleRelease`)।
`app/src/main/java/com/resellic/client/Api.kt`-এর `SITE` ধ্রুবকে সাইটের ঠিকানা আছে।
রিলিজ সাইন করতে `app/build.gradle.kts`-এ আপনার signingConfig যোগ করুন (অ্যাডমিন অ্যাপের মতো)।

## ফোন → সার্ভার কীভাবে
- লগইন → ডিভাইস-টোকেন (`app_client_devices` টেবিল, প্রথম কলে নিজে তৈরি হয়)।
  পাসওয়ার্ড বদলালে সব ডিভাইসের টোকেন বাতিল।
- নতুন অর্ডার ও অনলাইন পেমেন্ট (bKash/Nagad/কার্ড) সাইটের নিজস্ব নিরাপদ পাতায়:
  অ্যাপ `client-api.php?a=go` থেকে ২ মিনিটের এক-বারের লিংক নিয়ে ফোনের ব্রাউজারে খোলে।
  ওয়ালেট ব্যালেন্স দিয়ে ইনভয়েস পরিশোধ অ্যাপের ভেতরেই হয়।
- Two-step login চালু থাকা অ্যাকাউন্ট অ্যাপে ঢুকবে না (প্রথম সংস্করণ)।

## GitHub দিয়ে APK বানানো
`.github/workflows/build.yml` — `app/` বদলে push করলেই (বা Actions → Run workflow)
`Resellic-App.apk` তৈরি হয়ে **Artifacts**-এ পাওয়া যায়।

নিজের কী দিয়ে সাইন করতে (আপডেটের জন্য দরকার): Settings → Secrets and variables → Actions-এ
`KEYSTORE_BASE64` (জেকেএস ফাইলের base64), `KEYSTORE_PASSWORD`, `KEY_ALIAS`, `KEY_PASSWORD`।
এগুলো না দিলে ডিবাগ কী দিয়ে সাইন হয় — ইনস্টল চলে, কিন্তু প্রতিটা বিল্ড আলাদা কী, তাই আগেরটার ওপর আপডেট হবে না।
